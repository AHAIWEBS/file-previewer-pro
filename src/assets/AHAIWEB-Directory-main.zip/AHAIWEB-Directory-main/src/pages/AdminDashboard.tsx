import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import UserManagement from '@/components/admin/UserManagement';
import NewspaperManagement from '@/components/admin/NewspaperManagement';
import DirectoryManagement from '@/components/admin/DirectoryManagement';
import NewsSourcesManagement from '@/components/admin/NewsSourcesManagement';
import SiteSettings from '@/components/admin/SiteSettings';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Newspaper, LayoutDashboard, Settings, FolderOpen, Rss } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';

const AdminDashboard = () => {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalNewspapers: 0,
    activeNewspapers: 0,
    totalAdmins: 0,
  });

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate('/auth');
    }
  }, [user, isAdmin, loading, navigate]);

  useEffect(() => {
    const fetchStats = async () => {
      if (!user || !isAdmin) return;

      // Fetch user count
      const { count: userCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Fetch newspaper counts
      const { count: totalNewspapers } = await supabase
        .from('newspapers')
        .select('*', { count: 'exact', head: true });

      const { count: activeNewspapers } = await supabase
        .from('newspapers')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      // Fetch admin count
      const { count: adminCount } = await supabase
        .from('user_roles')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'admin');

      setStats({
        totalUsers: userCount || 0,
        totalNewspapers: totalNewspapers || 0,
        activeNewspapers: activeNewspapers || 0,
        totalAdmins: adminCount || 0,
      });
    };

    fetchStats();
  }, [user, isAdmin]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">অ্যাডমিন ড্যাশবোর্ড</h1>
          <p className="text-muted-foreground">
            স্বাগতম, {user.email}। এখান থেকে আপনি সম্পূর্ণ সাইট ম্যানেজ করতে পারবেন।
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-flex">
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">ওভারভিউ</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">ব্যবহারকারী</span>
            </TabsTrigger>
            <TabsTrigger value="newspapers" className="gap-2">
              <Newspaper className="h-4 w-4" />
              <span className="hidden sm:inline">পত্রিকা</span>
            </TabsTrigger>
            <TabsTrigger value="news-sources" className="gap-2">
              <Rss className="h-4 w-4" />
              <span className="hidden sm:inline">নিউজ সোর্স</span>
            </TabsTrigger>
            <TabsTrigger value="directory" className="gap-2">
              <FolderOpen className="h-4 w-4" />
              <span className="hidden sm:inline">ডিরেক্টরি</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">সেটিংস</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">মোট ব্যবহারকারী</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalUsers}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">মোট পত্রিকা</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalNewspapers}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">সক্রিয় পত্রিকা</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.activeNewspapers}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">অ্যাডমিন</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalAdmins}</div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          <TabsContent value="newspapers">
            <NewspaperManagement />
          </TabsContent>

          <TabsContent value="news-sources">
            <NewsSourcesManagement />
          </TabsContent>

          <TabsContent value="directory">
            <DirectoryManagement />
          </TabsContent>

          <TabsContent value="settings">
            <SiteSettings />
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
};

export default AdminDashboard;
