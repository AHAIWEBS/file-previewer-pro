import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ExternalLink, Newspaper } from "lucide-react";

const divisionData = [
  {
    name: "ঢাকা বিভাগ",
    nameEn: "Dhaka Division",
    districts: [
      {
        name: "ঢাকা",
        newspapers: [
          { name: "প্রথম আলো", link: "https://www.prothomalo.com" },
          { name: "কালের কণ্ঠ", link: "https://www.kalerkantho.com" },
          { name: "যুগান্তর", link: "https://www.jugantor.com" },
          { name: "সমকাল", link: "https://samakal.com" },
          { name: "ইত্তেফাক", link: "https://www.ittefaq.com.bd" },
          { name: "বাংলাদেশ প্রতিদিন", link: "https://www.bd-pratidin.com" },
          { name: "মানবজমিন", link: "https://www.mzamin.com" },
          { name: "জনকণ্ঠ", link: "https://www.dailyjanakantha.com" },
          { name: "নয়া দিগন্ত", link: "https://www.dailynayadiganta.com" },
          { name: "ইনকিলাব", link: "https://www.dailyinqilab.com" },
        ],
      },
      {
        name: "গাজীপুর",
        newspapers: [
          { name: "গাজীপুর কণ্ঠ", link: "https://www.gazipurkantho.com" },
          { name: "দৈনিক গাজীপুর", link: "#" },
        ],
      },
      {
        name: "নারায়ণগঞ্জ",
        newspapers: [
          { name: "দৈনিক নারায়ণগঞ্জ", link: "#" },
          { name: "নারায়ণগঞ্জ প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "মানিকগঞ্জ",
        newspapers: [
          { name: "মানিকগঞ্জের খবর", link: "#" },
        ],
      },
      {
        name: "মুন্সীগঞ্জ",
        newspapers: [
          { name: "মুন্সীগঞ্জ বার্তা", link: "#" },
        ],
      },
      {
        name: "ফরিদপুর",
        newspapers: [
          { name: "দৈনিক ফরিদপুর", link: "#" },
          { name: "ফরিদপুরের ডাক", link: "#" },
        ],
      },
      {
        name: "মাদারীপুর",
        newspapers: [
          { name: "মাদারীপুর সংবাদ", link: "#" },
        ],
      },
      {
        name: "গোপালগঞ্জ",
        newspapers: [
          { name: "গোপালগঞ্জ প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "টাঙ্গাইল",
        newspapers: [
          { name: "দৈনিক টাঙ্গাইল", link: "#" },
          { name: "টাঙ্গাইলের কথা", link: "#" },
        ],
      },
      {
        name: "কিশোরগঞ্জ",
        newspapers: [
          { name: "কিশোরগঞ্জ সংবাদ", link: "#" },
        ],
      },
    ],
  },
  {
    name: "চট্টগ্রাম বিভাগ",
    nameEn: "Chittagong Division",
    districts: [
      {
        name: "চট্টগ্রাম",
        newspapers: [
          { name: "দৈনিক আজাদী", link: "https://www.azadibd.com" },
          { name: "দৈনিক পূর্বকোণ", link: "https://www.purbokone.com" },
          { name: "দৈনিক পূর্বদেশ", link: "https://www.dainikpurbodesh.com" },
          { name: "সুপ্রভাত বাংলাদেশ", link: "https://www.suprobhat.com" },
          { name: "দৈনিক কক্সবাজার", link: "#" },
        ],
      },
      {
        name: "কক্সবাজার",
        newspapers: [
          { name: "কক্সবাজার নিউজ", link: "#" },
          { name: "দৈনিক কক্সবাজার", link: "#" },
          { name: "কক্সবাজার বার্তা", link: "#" },
        ],
      },
      {
        name: "কুমিল্লা",
        newspapers: [
          { name: "দৈনিক কুমিল্লার কাগজ", link: "#" },
          { name: "কুমিল্লার খবর", link: "#" },
        ],
      },
      {
        name: "ব্রাহ্মণবাড়িয়া",
        newspapers: [
          { name: "ব্রাহ্মণবাড়িয়া প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "ফেনী",
        newspapers: [
          { name: "ফেনীর কণ্ঠ", link: "#" },
        ],
      },
      {
        name: "নোয়াখালী",
        newspapers: [
          { name: "নোয়াখালী সংবাদ", link: "#" },
          { name: "দৈনিক নোয়াখালী", link: "#" },
        ],
      },
      {
        name: "লক্ষ্মীপুর",
        newspapers: [
          { name: "লক্ষ্মীপুর বার্তা", link: "#" },
        ],
      },
      {
        name: "চাঁদপুর",
        newspapers: [
          { name: "চাঁদপুর কণ্ঠ", link: "#" },
        ],
      },
      {
        name: "রাঙ্গামাটি",
        newspapers: [
          { name: "পার্বত্য চট্টগ্রাম সংবাদ", link: "#" },
        ],
      },
      {
        name: "বান্দরবান",
        newspapers: [
          { name: "বান্দরবান সংবাদ", link: "#" },
        ],
      },
      {
        name: "খাগড়াছড়ি",
        newspapers: [
          { name: "খাগড়াছড়ি প্রতিদিন", link: "#" },
        ],
      },
    ],
  },
  {
    name: "রাজশাহী বিভাগ",
    nameEn: "Rajshahi Division",
    districts: [
      {
        name: "রাজশাহী",
        newspapers: [
          { name: "দৈনিক সোনার দেশ", link: "https://www.sonardesh.com" },
          { name: "রাজশাহী নিউজ", link: "#" },
          { name: "দৈনিক বরেন্দ্র বার্তা", link: "#" },
        ],
      },
      {
        name: "বগুড়া",
        newspapers: [
          { name: "দৈনিক করতোয়া", link: "#" },
          { name: "বগুড়া প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "নওগাঁ",
        newspapers: [
          { name: "নওগাঁ সংবাদ", link: "#" },
        ],
      },
      {
        name: "নাটোর",
        newspapers: [
          { name: "নাটোর বার্তা", link: "#" },
        ],
      },
      {
        name: "চাঁপাইনবাবগঞ্জ",
        newspapers: [
          { name: "চাঁপাইনবাবগঞ্জ প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "পাবনা",
        newspapers: [
          { name: "পাবনার খবর", link: "#" },
          { name: "দৈনিক পাবনা", link: "#" },
        ],
      },
      {
        name: "সিরাজগঞ্জ",
        newspapers: [
          { name: "সিরাজগঞ্জ সংবাদ", link: "#" },
        ],
      },
      {
        name: "জয়পুরহাট",
        newspapers: [
          { name: "জয়পুরহাট বার্তা", link: "#" },
        ],
      },
    ],
  },
  {
    name: "খুলনা বিভাগ",
    nameEn: "Khulna Division",
    districts: [
      {
        name: "খুলনা",
        newspapers: [
          { name: "দৈনিক পদ্মা", link: "#" },
          { name: "খুলনা সংবাদ", link: "#" },
          { name: "দৈনিক জনপদ", link: "#" },
        ],
      },
      {
        name: "যশোর",
        newspapers: [
          { name: "দৈনিক গ্রামের কাগজ", link: "#" },
          { name: "যশোর প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "সাতক্ষীরা",
        newspapers: [
          { name: "সাতক্ষীরা সংবাদ", link: "#" },
        ],
      },
      {
        name: "নড়াইল",
        newspapers: [
          { name: "নড়াইল বার্তা", link: "#" },
        ],
      },
      {
        name: "মাগুরা",
        newspapers: [
          { name: "মাগুরা প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "কুষ্টিয়া",
        newspapers: [
          { name: "কুষ্টিয়া সংবাদ", link: "#" },
          { name: "দৈনিক কুষ্টিয়া", link: "#" },
        ],
      },
      {
        name: "মেহেরপুর",
        newspapers: [
          { name: "মেহেরপুর বার্তা", link: "#" },
        ],
      },
      {
        name: "চুয়াডাঙ্গা",
        newspapers: [
          { name: "চুয়াডাঙ্গা প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "ঝিনাইদহ",
        newspapers: [
          { name: "ঝিনাইদহ সংবাদ", link: "#" },
        ],
      },
      {
        name: "বাগেরহাট",
        newspapers: [
          { name: "বাগেরহাট বার্তা", link: "#" },
        ],
      },
    ],
  },
  {
    name: "সিলেট বিভাগ",
    nameEn: "Sylhet Division",
    districts: [
      {
        name: "সিলেট",
        newspapers: [
          { name: "দৈনিক সিলেটের ডাক", link: "https://www.sylheterdhak.com" },
          { name: "সিলেট মিরর", link: "#" },
          { name: "দৈনিক সিলেট", link: "#" },
          { name: "সুরমা", link: "#" },
        ],
      },
      {
        name: "মৌলভীবাজার",
        newspapers: [
          { name: "মৌলভীবাজার সংবাদ", link: "#" },
        ],
      },
      {
        name: "হবিগঞ্জ",
        newspapers: [
          { name: "হবিগঞ্জ প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "সুনামগঞ্জ",
        newspapers: [
          { name: "সুনামগঞ্জ বার্তা", link: "#" },
          { name: "হাওর বার্তা", link: "#" },
        ],
      },
    ],
  },
  {
    name: "বরিশাল বিভাগ",
    nameEn: "Barisal Division",
    districts: [
      {
        name: "বরিশাল",
        newspapers: [
          { name: "দৈনিক আজকের বার্তা", link: "#" },
          { name: "বরিশাল প্রতিদিন", link: "#" },
          { name: "দক্ষিণাঞ্চল", link: "#" },
        ],
      },
      {
        name: "পটুয়াখালী",
        newspapers: [
          { name: "পটুয়াখালী সংবাদ", link: "#" },
        ],
      },
      {
        name: "ভোলা",
        newspapers: [
          { name: "ভোলার খবর", link: "#" },
        ],
      },
      {
        name: "বরগুনা",
        newspapers: [
          { name: "বরগুনা বার্তা", link: "#" },
        ],
      },
      {
        name: "পিরোজপুর",
        newspapers: [
          { name: "পিরোজপুর প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "ঝালকাঠি",
        newspapers: [
          { name: "ঝালকাঠি সংবাদ", link: "#" },
        ],
      },
    ],
  },
  {
    name: "রংপুর বিভাগ",
    nameEn: "Rangpur Division",
    districts: [
      {
        name: "রংপুর",
        newspapers: [
          { name: "দৈনিক প্রথম বাংলা", link: "#" },
          { name: "রংপুর প্রতিদিন", link: "#" },
          { name: "উত্তরবাংলা", link: "#" },
        ],
      },
      {
        name: "দিনাজপুর",
        newspapers: [
          { name: "দিনাজপুর প্রতিদিন", link: "#" },
          { name: "দৈনিক দিনাজপুর", link: "#" },
        ],
      },
      {
        name: "ঠাকুরগাঁও",
        newspapers: [
          { name: "ঠাকুরগাঁও সংবাদ", link: "#" },
        ],
      },
      {
        name: "পঞ্চগড়",
        newspapers: [
          { name: "পঞ্চগড় বার্তা", link: "#" },
        ],
      },
      {
        name: "নীলফামারী",
        newspapers: [
          { name: "নীলফামারী প্রতিদিন", link: "#" },
        ],
      },
      {
        name: "লালমনিরহাট",
        newspapers: [
          { name: "লালমনিরহাট সংবাদ", link: "#" },
        ],
      },
      {
        name: "কুড়িগ্রাম",
        newspapers: [
          { name: "কুড়িগ্রাম বার্তা", link: "#" },
        ],
      },
      {
        name: "গাইবান্ধা",
        newspapers: [
          { name: "গাইবান্ধা প্রতিদিন", link: "#" },
        ],
      },
    ],
  },
  {
    name: "ময়মনসিংহ বিভাগ",
    nameEn: "Mymensingh Division",
    districts: [
      {
        name: "ময়মনসিংহ",
        newspapers: [
          { name: "দৈনিক ময়মনসিংহ", link: "#" },
          { name: "ময়মনসিংহ প্রতিদিন", link: "#" },
          { name: "ব্রহ্মপুত্র বার্তা", link: "#" },
        ],
      },
      {
        name: "জামালপুর",
        newspapers: [
          { name: "জামালপুর সংবাদ", link: "#" },
        ],
      },
      {
        name: "শেরপুর",
        newspapers: [
          { name: "শেরপুর বার্তা", link: "#" },
        ],
      },
      {
        name: "নেত্রকোনা",
        newspapers: [
          { name: "নেত্রকোনা প্রতিদিন", link: "#" },
        ],
      },
    ],
  },
];

const onlinePortals = [
  {
    category: "জাতীয় অনলাইন নিউজ পোর্টাল",
    categoryEn: "National Online News Portals",
    portals: [
      { name: "বিডিনিউজ২৪", link: "https://bdnews24.com" },
      { name: "বাংলা ট্রিবিউন", link: "https://www.banglatribune.com" },
      { name: "জাগো নিউজ", link: "https://www.jagonews24.com" },
      { name: "ঢাকা পোস্ট", link: "https://www.dhakapost.com" },
      { name: "নিউজ বাংলা", link: "https://www.newsbangla24.com" },
      { name: "বাংলানিউজ", link: "https://www.banglanews24.com" },
      { name: "রাইজিংবিডি", link: "https://www.risingbd.com" },
      { name: "ডেইলি বাংলাদেশ", link: "https://www.daily-bangladesh.com" },
      { name: "একুশে নিউজ", link: "https://www.ekushey-tv.com" },
      { name: "চ্যানেল আই অনলাইন", link: "https://www.channelionline.com" },
    ],
  },
  {
    category: "আন্তর্জাতিক বাংলা নিউজ",
    categoryEn: "International Bangla News",
    portals: [
      { name: "বিবিসি বাংলা", link: "https://www.bbc.com/bengali" },
      { name: "ভয়েস অফ আমেরিকা বাংলা", link: "https://www.voabangla.com" },
      { name: "ডয়চে ভেলে বাংলা", link: "https://www.dw.com/bn" },
      { name: "আনন্দবাজার", link: "https://www.anandabazar.com" },
      { name: "এই সময়", link: "https://eisamay.com" },
    ],
  },
  {
    category: "ইংরেজি নিউজ পোর্টাল",
    categoryEn: "English News Portals",
    portals: [
      { name: "The Daily Star", link: "https://www.thedailystar.net" },
      { name: "Dhaka Tribune", link: "https://www.dhakatribune.com" },
      { name: "The Business Standard", link: "https://www.tbsnews.net" },
      { name: "New Age", link: "https://www.newagebd.net" },
      { name: "The Financial Express", link: "https://thefinancialexpress.com.bd" },
      { name: "The Independent", link: "https://www.theindependentbd.com" },
      { name: "Bangladesh Post", link: "https://www.bangladeshpost.net" },
    ],
  },
];

const DivisionNewspapers = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-2">বিভাগ ও জেলাভিত্তিক পত্রিকা</h1>
          <p className="text-muted-foreground">
            বাংলাদেশের সকল বিভাগ ও জেলার পত্রিকা এবং অনলাইন নিউজ পোর্টাল
          </p>
        </div>

        {/* Online News Portals Section */}
        <section className="mb-12">
          <div className="bg-accent text-accent-foreground px-4 py-3 rounded-t-lg flex items-center gap-2">
            <Newspaper className="w-5 h-5" />
            <h2 className="text-xl font-bold">অনলাইন নিউজ পোর্টাল</h2>
          </div>
          <div className="border border-t-0 rounded-b-lg p-4 space-y-6">
            {onlinePortals.map((section) => (
              <div key={section.categoryEn}>
                <h3 className="font-semibold text-lg mb-3 text-primary">
                  {section.category}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
                  {section.portals.map((portal) => (
                    <a
                      key={portal.name}
                      href={portal.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 p-2 rounded-lg bg-muted hover:bg-primary hover:text-primary-foreground transition-colors text-sm"
                    >
                      <ExternalLink className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{portal.name}</span>
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Division-wise Newspapers */}
        {divisionData.map((division) => (
          <section key={division.nameEn} className="mb-10">
            <div className="bg-primary text-primary-foreground px-4 py-3 rounded-t-lg">
              <h2 className="text-xl font-bold">
                {division.name} ({division.nameEn})
              </h2>
            </div>
            <div className="border border-t-0 rounded-b-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {division.districts.map((district) => (
                  <div
                    key={district.name}
                    className="bg-muted rounded-lg p-4"
                  >
                    <h3 className="font-semibold text-primary mb-3 border-b pb-2">
                      {district.name}
                    </h3>
                    <div className="space-y-1">
                      {district.newspapers.map((paper) => (
                        <a
                          key={paper.name}
                          href={paper.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm hover:text-primary transition-colors py-1"
                        >
                          <ExternalLink className="w-3 h-3 flex-shrink-0" />
                          <span>{paper.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>

      <Footer />
    </div>
  );
};

export default DivisionNewspapers;
