import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useDirectoryData } from "@/hooks/useDirectoryData";
import { Loader2 } from "lucide-react";

const AI = () => {
  const { groupedItems, loading, error } = useDirectoryData('ai');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-2">
          এআই টুলস
        </h1>
        <p className="text-center text-muted-foreground mb-8">
          জনপ্রিয় আর্টিফিশিয়াল ইন্টেলিজেন্স টুলস
        </p>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <p className="text-center text-destructive">{error}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {groupedItems.map((section) => (
              <section key={section.subcategory} className="bg-card border rounded-xl overflow-hidden">
                <div className="bg-primary text-primary-foreground px-4 py-3">
                  <h2 className="text-lg font-bold">{section.subcategory}</h2>
                </div>
                <div className="p-4">
                  <div className="space-y-2">
                    {section.items.map((item) => (
                      <a
                        key={item.id}
                        href={item.url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block p-3 rounded-lg border hover:bg-accent transition-colors"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{item.name_bn}</p>
                            {item.name_en && (
                              <p className="text-xs text-muted-foreground">{item.name_en}</p>
                            )}
                          </div>
                        </div>
                        {item.description && (
                          <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                        )}
                      </a>
                    ))}
                  </div>
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default AI;
