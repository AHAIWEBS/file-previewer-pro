import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Phone as PhoneIcon, Loader2 } from "lucide-react";
import { useDirectoryData } from "@/hooks/useDirectoryData";

const Phone = () => {
  const { groupedItems, loading, error } = useDirectoryData('phone');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          ফোন ডিরেক্টরি
        </h1>
        
        {loading && (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}

        {error && (
          <div className="text-center text-destructive py-12">{error}</div>
        )}

        {!loading && !error && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {groupedItems.map((section) => (
              <section key={section.subcategory} className="bg-card border rounded-xl overflow-hidden">
                <div className="bg-primary text-primary-foreground px-4 py-3 flex items-center gap-3">
                  <PhoneIcon className="w-6 h-6" />
                  <h2 className="text-lg font-bold">{section.subcategory}</h2>
                </div>
                <div className="p-4">
                  <div className="space-y-2">
                    {section.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-accent transition-colors"
                      >
                        <span className="text-sm">{item.name_bn}</span>
                        <a
                          href={`tel:${item.phone}`}
                          className="flex items-center gap-1 text-primary font-medium text-sm hover:underline"
                        >
                          <PhoneIcon className="w-3 h-3" />
                          {item.phone}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Phone;
