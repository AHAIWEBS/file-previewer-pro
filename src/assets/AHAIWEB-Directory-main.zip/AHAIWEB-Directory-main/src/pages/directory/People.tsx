import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useDirectoryData } from "@/hooks/useDirectoryData";
import { Loader2 } from "lucide-react";

const People = () => {
  const { groupedItems, loading, error } = useDirectoryData('people');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          বিশিষ্ট ব্যক্তিত্ব
        </h1>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <p className="text-center text-destructive">{error}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {groupedItems.map((section) => (
              <section key={section.subcategory} className="bg-card border rounded-xl overflow-hidden">
                <div className="bg-primary text-primary-foreground px-4 py-3">
                  <h2 className="text-lg font-bold">{section.subcategory}</h2>
                </div>
                <div className="p-4">
                  <div className="space-y-2">
                    {section.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex justify-between items-center p-3 rounded-lg border hover:bg-accent transition-colors"
                      >
                        <div>
                          <p className="font-medium">{item.name_bn}</p>
                          {item.name_en && (
                            <p className="text-xs text-muted-foreground">{item.name_en}</p>
                          )}
                        </div>
                        {item.description && (
                          <span className="text-sm text-muted-foreground bg-secondary px-2 py-1 rounded">
                            {item.description}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default People;
