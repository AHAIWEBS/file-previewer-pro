import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ExternalLink, Loader2 } from "lucide-react";
import { useDirectoryData } from "@/hooks/useDirectoryData";

const Government = () => {
  const { groupedItems, loading, error } = useDirectoryData('government');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          সরকারি ওয়েবসাইট ডিরেক্টরি
        </h1>
        
        {loading && (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}

        {error && (
          <div className="text-center text-destructive py-12">{error}</div>
        )}

        {!loading && !error && groupedItems.map((section) => (
          <section key={section.subcategory} className="mb-8">
            <div className="bg-primary text-primary-foreground px-4 py-3 rounded-t-lg">
              <h2 className="text-xl font-bold">{section.subcategory}</h2>
            </div>
            <div className="border border-t-0 rounded-b-lg p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {section.items.map((link) => (
                  <a
                    key={link.id}
                    href={link.url || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 p-3 rounded-lg border bg-card hover:bg-accent transition-colors group"
                  >
                    <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-primary" />
                    <div>
                      <p className="font-medium text-sm">{link.name_bn}</p>
                      {link.name_en && <p className="text-xs text-muted-foreground">{link.name_en}</p>}
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>

      <Footer />
    </div>
  );
};

export default Government;
