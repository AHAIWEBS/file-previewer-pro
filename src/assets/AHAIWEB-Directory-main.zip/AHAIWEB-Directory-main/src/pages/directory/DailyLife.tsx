import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useDirectoryData } from "@/hooks/useDirectoryData";
import { Loader2 } from "lucide-react";

const DailyLife = () => {
  const { groupedItems, loading, error } = useDirectoryData('daily-life');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          দৈনন্দিন জীবন
        </h1>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <p className="text-center text-destructive">{error}</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groupedItems.map((section) => (
              <section key={section.subcategory} className="bg-card border rounded-xl overflow-hidden">
                <div className="bg-primary text-primary-foreground px-4 py-3">
                  <h2 className="text-base font-bold">{section.subcategory}</h2>
                </div>
                <div className="p-3">
                  <div className="space-y-1">
                    {section.items.map((item) => (
                      <a
                        key={item.id}
                        href={item.url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex justify-between items-center p-2 rounded-lg hover:bg-accent transition-colors text-sm"
                      >
                        <span>{item.name_bn}</span>
                        {item.name_en && (
                          <span className="text-xs text-muted-foreground">{item.name_en}</span>
                        )}
                      </a>
                    ))}
                  </div>
                </div>
              </section>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default DailyLife;
