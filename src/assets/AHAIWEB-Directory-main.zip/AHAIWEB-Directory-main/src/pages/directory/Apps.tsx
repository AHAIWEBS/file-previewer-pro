import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useDirectoryData } from "@/hooks/useDirectoryData";
import { Loader2 } from "lucide-react";

const Apps = () => {
  const { groupedItems, loading, error } = useDirectoryData('apps');

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          অ্যাপস
        </h1>
        
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <p className="text-center text-destructive">{error}</p>
        ) : (
          groupedItems.map((section) => (
            <section key={section.subcategory} className="mb-8">
              <div className="bg-primary text-primary-foreground px-4 py-3 rounded-t-lg">
                <h2 className="text-xl font-bold">{section.subcategory}</h2>
              </div>
              <div className="border border-t-0 rounded-b-lg p-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {section.items.map((item) => (
                    <a
                      key={item.id}
                      href={item.url || '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col p-4 rounded-lg border bg-card hover:bg-accent transition-colors"
                    >
                      <p className="font-medium">{item.name_bn}</p>
                      {item.name_en && (
                        <p className="text-xs text-muted-foreground mb-1">{item.name_en}</p>
                      )}
                      {item.description && (
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      )}
                    </a>
                  ))}
                </div>
              </div>
            </section>
          ))
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Apps;
