import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Tv, Globe } from "lucide-react";

const tvCategories = [
  {
    icon: Tv,
    category: "বাংলাদেশি টিভি চ্যানেল",
    categoryEn: "Bangladeshi TV",
    color: "bg-red-500",
    channels: [
      { name: "বিটিভি", nameEn: "BTV", url: "https://www.btv.gov.bd" },
      { name: "এটিএন বাংলা", nameEn: "ATN Bangla", url: "https://www.atnbangla.tv" },
      { name: "চ্যানেল আই", nameEn: "Channel I", url: "https://www.channeli.tv" },
      { name: "এনটিভি", nameEn: "NTV", url: "https://www.ntvbd.com" },
      { name: "আরটিভি", nameEn: "RTV", url: "https://www.raborokotv.com" },
      { name: "সময় টিভি", nameEn: "Somoy TV", url: "https://www.somoynews.tv" },
      { name: "একুশে টিভি", nameEn: "Ekushey TV", url: "https://www.ekushey-tv.com" },
      { name: "বৈশাখী টিভি", nameEn: "Boishakhi TV", url: "https://www.boishakhionline.com" },
      { name: "দেশ টিভি", nameEn: "Desh TV", url: "https://www.deshtv.tv" },
      { name: "মাছরাঙা টিভি", nameEn: "Maasranga TV", url: "https://www.maasranga.tv" },
      { name: "গাজী টিভি", nameEn: "Gazi TV", url: "https://www.gazitv.com" },
      { name: "জমুনা টিভি", nameEn: "Jamuna TV", url: "https://www.jamuna.tv" },
      { name: "ইন্ডিপেন্ডেন্ট টিভি", nameEn: "Independent TV", url: "https://www.independenttv.com.bd" },
      { name: "নেক্সাস টিভি", nameEn: "Nexus TV", url: "https://www.nexustv.com.bd" },
    ],
  },
  {
    icon: Globe,
    category: "আন্তর্জাতিক টিভি",
    categoryEn: "International TV",
    color: "bg-blue-500",
    channels: [
      { name: "বিবিসি বাংলা", nameEn: "BBC Bangla", url: "https://www.bbc.com/bengali" },
      { name: "ভয়েস অফ আমেরিকা বাংলা", nameEn: "VOA Bangla", url: "https://www.voabangla.com" },
      { name: "ডয়চে ভেলে বাংলা", nameEn: "DW Bangla", url: "https://www.dw.com/bn" },
      { name: "আল জাজিরা", nameEn: "Al Jazeera", url: "https://www.aljazeera.com" },
      { name: "সিএনএন", nameEn: "CNN", url: "https://www.cnn.com" },
      { name: "বিবিসি ওয়ার্ল্ড", nameEn: "BBC World", url: "https://www.bbc.com/news" },
      { name: "স্টার প্লাস", nameEn: "Star Plus", url: "https://www.hotstar.com" },
      { name: "জি বাংলা", nameEn: "Zee Bangla", url: "https://www.zee5.com" },
      { name: "সনি টিভি", nameEn: "Sony TV", url: "https://www.sonyliv.com" },
      { name: "কালার্স বাংলা", nameEn: "Colors Bangla", url: "https://www.voot.com" },
    ],
  },
];

const TV = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          টিভি চ্যানেল
        </h1>
        
        {tvCategories.map((section) => (
          <section key={section.categoryEn} className="mb-8">
            <div className={`${section.color} text-white px-4 py-3 rounded-t-lg flex items-center gap-3`}>
              <section.icon className="w-6 h-6" />
              <h2 className="text-xl font-bold">
                {section.category} ({section.categoryEn})
              </h2>
            </div>
            <div className="border border-t-0 rounded-b-lg p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {section.channels.map((channel) => (
                  <a
                    key={channel.nameEn}
                    href={channel.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center p-4 rounded-lg border bg-card hover:bg-accent transition-colors text-center"
                  >
                    <Tv className="w-8 h-8 mb-2 text-primary" />
                    <p className="font-medium text-sm">{channel.name}</p>
                    <p className="text-xs text-muted-foreground">{channel.nameEn}</p>
                  </a>
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>

      <Footer />
    </div>
  );
};

export default TV;
