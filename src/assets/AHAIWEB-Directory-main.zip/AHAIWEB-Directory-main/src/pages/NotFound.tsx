import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h1 className="mb-4 text-6xl font-bold text-primary">৪০৪</h1>
          <p className="mb-4 text-xl text-muted-foreground">পেইজটি খুঁজে পাওয়া যায়নি</p>
          <Link to="/" className="text-primary hover:underline font-medium">
            হোম পেইজে ফিরে যান
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default NotFound;
