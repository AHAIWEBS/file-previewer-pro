import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NewspaperCard from "@/components/NewspaperCard";

import prothomAlo from "@/assets/newspapers/prothom-alo.png";
import bangladeshPratidin from "@/assets/newspapers/bangladesh-pratidin.png";
import kalerKantho from "@/assets/newspapers/kaler-kantho.png";
import samakal from "@/assets/newspapers/samakal.png";
import jugantor from "@/assets/newspapers/jugantor.png";
import manabZamin from "@/assets/newspapers/manab-zamin.png";
import inqilab from "@/assets/newspapers/inqilab.png";
import nayaDiganta from "@/assets/newspapers/naya-diganta.png";
import ittefaq from "@/assets/newspapers/ittefaq.png";
import janakantha from "@/assets/newspapers/janakantha.png";
import kalBela from "@/assets/newspapers/kal-bela.png";
import jaijaidin from "@/assets/newspapers/jaijaidin.png";
import dailyStar from "@/assets/newspapers/daily-star.png";
import deshRupantor from "@/assets/newspapers/desh-rupantor.png";
import ajkerPatrika from "@/assets/newspapers/ajker-patrika.png";
import amarSangbad from "@/assets/newspapers/amar-sangbad.png";
import dainikBangla from "@/assets/newspapers/dainik-bangla.png";
import sangbad from "@/assets/newspapers/sangbad.png";
import amaderShomoy from "@/assets/newspapers/amader-shomoy.png";
import amardesh from "@/assets/newspapers/amardesh.png";
import manobkantha from "@/assets/newspapers/manobkantha.png";

const categories = [
  {
    name: "দৈনিক পত্রিকা",
    nameEn: "Daily Newspapers",
    newspapers: [
      { name: "প্রথম আলো", logo: prothomAlo, link: "https://www.prothomalo.com" },
      { name: "বাংলাদেশ প্রতিদিন", logo: bangladeshPratidin, link: "https://www.bd-pratidin.com" },
      { name: "কালের কণ্ঠ", logo: kalerKantho, link: "https://www.kalerkantho.com" },
      { name: "সমকাল", logo: samakal, link: "https://samakal.com" },
      { name: "যুগান্তর", logo: jugantor, link: "https://www.jugantor.com" },
      { name: "মানবজমিন", logo: manabZamin, link: "https://www.mzamin.com" },
      { name: "ইনকিলাব", logo: inqilab, link: "https://www.dailyinqilab.com" },
      { name: "নয়া দিগন্ত", logo: nayaDiganta, link: "https://www.dailynayadiganta.com" },
      { name: "ইত্তেফাক", logo: ittefaq, link: "https://www.ittefaq.com.bd" },
      { name: "জনকণ্ঠ", logo: janakantha, link: "https://www.dailyjanakantha.com" },
    ],
  },
  {
    name: "অনলাইন নিউজ",
    nameEn: "Online News",
    newspapers: [
      { name: "কালবেলা", logo: kalBela, link: "https://www.kalbela.com" },
      { name: "জাগো নিউজ", logo: jaijaidin, link: "https://www.jaijaidinbd.com" },
      { name: "দেশ রূপান্তর", logo: deshRupantor, link: "https://www.deshrupantor.com" },
      { name: "আজকের পত্রিকা", logo: ajkerPatrika, link: "https://www.ajkerpatrika.com" },
      { name: "আমার সংবাদ", logo: amarSangbad, link: "https://www.amarsangbad.com" },
      { name: "মানবকণ্ঠ", logo: manobkantha, link: "https://www.manobkantha.com.bd" },
    ],
  },
  {
    name: "টিভি চ্যানেল",
    nameEn: "TV Channels",
    newspapers: [
      { name: "আমাদের সময়", logo: amaderShomoy, link: "https://www.amadershomoy.com" },
      { name: "দৈনিক বাংলা", logo: dainikBangla, link: "https://www.dainikbangla.com.bd" },
      { name: "সংবাদ", logo: sangbad, link: "https://www.sangbad.com.bd" },
    ],
  },
  {
    name: "ইংরেজি পত্রিকা",
    nameEn: "English Newspapers",
    newspapers: [
      { name: "The Daily Star", logo: dailyStar, link: "https://www.thedailystar.net" },
      { name: "আমারদেশ", logo: amardesh, link: "https://www.amardesh.com" },
    ],
  },
];

const Categories = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          সকল ক্যাটাগরি
        </h1>
        
        {categories.map((category) => (
          <section key={category.nameEn} className="mb-12">
            <div className="bg-primary text-primary-foreground px-4 py-3 rounded-t-lg">
              <h2 className="text-xl font-bold">
                {category.name} ({category.nameEn})
              </h2>
            </div>
            <div className="border border-t-0 rounded-b-lg p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {category.newspapers.map((newspaper) => (
                  <NewspaperCard
                    key={newspaper.name}
                    name={newspaper.name}
                    logo={newspaper.logo}
                    link={newspaper.link}
                  />
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>

      <Footer />
    </div>
  );
};

export default Categories;
