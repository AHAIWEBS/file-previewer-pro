import { useState, useEffect, useMemo } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NewsletterBanner from "@/components/NewsletterBanner";
import NewspaperCard from "@/components/NewspaperCard";
import NewsSlider from "@/components/NewsSlider";
import LeftSidebar from "@/components/LeftSidebar";
import RightSidebar from "@/components/RightSidebar";
import CategoryFilter from "@/components/CategoryFilter";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

interface Newspaper {
  id: string;
  name: string;
  name_bn: string;
  url: string;
  logo_url: string | null;
  category: string;
}

const categories = [
  { value: 'national', label: 'জাতীয়' },
  { value: 'international', label: 'আন্তর্জাতিক' },
  { value: 'divisional', label: 'বিভাগীয়' },
  { value: 'district', label: 'জেলা' },
  { value: 'online', label: 'অনলাইন' },
];

const Index = () => {
  const [newspapers, setNewspapers] = useState<Newspaper[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    const fetchNewspapers = async () => {
      try {
        const { data, error } = await supabase
          .from('newspapers')
          .select('id, name, name_bn, url, logo_url, category')
          .eq('is_active', true)
          .order('created_at', { ascending: true });

        if (error) throw error;
        setNewspapers(data || []);
      } catch (error) {
        console.error('Error fetching newspapers:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNewspapers();
  }, []);

  // Filter newspapers by category
  const filteredNewspapers = useMemo(() => {
    if (!selectedCategory) return newspapers;
    return newspapers.filter(n => n.category === selectedCategory);
  }, [newspapers, selectedCategory]);

  // Get top 10 filtered newspapers
  const topNewspapers = filteredNewspapers.slice(0, 10);
  const otherNewspapers = filteredNewspapers.slice(10);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <NewsletterBanner />

      <main className="container mx-auto px-4 py-8">
        {/* News Slider - RSS Feed */}
        <section className="mb-8">
          <NewsSlider />
        </section>

        {/* Category Filter */}
        <section className="mb-6">
          <CategoryFilter
            categories={categories}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </section>

        {/* 3-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr_240px] gap-6">
          {/* Left Sidebar */}
          <div className="hidden lg:block">
            <LeftSidebar />
          </div>

          {/* Main Content */}
          <div className="min-w-0">
            {/* Top 10 Section */}
            <section className="mb-8">
              <div className="bg-primary text-primary-foreground py-3 px-6 mb-6 text-center rounded-lg">
                <h2 className="text-lg font-bold tracking-wide">
                  {selectedCategory 
                    ? `${categories.find(c => c.value === selectedCategory)?.label || ''} পত্রিকা`
                    : 'TOP 10 WITH ALL BANGLA NEWSPAPERS'
                  }
                </h2>
              </div>

              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredNewspapers.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">এই ক্যাটাগরিতে কোনো পত্রিকা নেই</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4 mb-6">
                  {topNewspapers.map((newspaper) => (
                    <NewspaperCard
                      key={newspaper.id}
                      name={newspaper.name_bn}
                      logo={newspaper.logo_url || '/placeholder.svg'}
                      link={newspaper.url}
                    />
                  ))}
                </div>
              )}

              {!selectedCategory && (
                <div className="text-center max-w-3xl mx-auto">
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Bangla is a popular and influential language. It is the state language of Bangladesh; 
                    Bangla is a particular state language in some countries, including India.
                  </p>
                  <a href="#" className="text-primary hover:underline font-medium text-sm">
                    Read More
                  </a>
                </div>
              )}
            </section>

            {/* All Newspapers Section */}
            {!loading && otherNewspapers.length > 0 && (
              <section>
                <div className="bg-secondary text-secondary-foreground py-2 px-4 mb-6 rounded-lg">
                  <h2 className="text-base font-semibold">
                    {selectedCategory ? 'আরও পত্রিকা' : 'সকল পত্রিকা'}
                  </h2>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-4">
                  {otherNewspapers.map((newspaper) => (
                    <NewspaperCard
                      key={newspaper.id}
                      name={newspaper.name_bn}
                      logo={newspaper.logo_url || '/placeholder.svg'}
                      link={newspaper.url}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="hidden lg:block">
            <RightSidebar />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Index;