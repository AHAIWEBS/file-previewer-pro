import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Globe, Newspaper, Tv, Phone, Plane, ShoppingBag, Monitor, Share2, Smartphone, Bot, Users } from "lucide-react";
import { Link } from "react-router-dom";

const directoryCategories = [
  {
    icon: Globe,
    title: "সরকারি ওয়েবসাইট",
    titleEn: "Government Directory",
    description: "জাতীয়, মন্ত্রণালয়, বিভাগ, জেলা ও উপজেলা পর্যায়ের সরকারি সাইট",
    link: "/directory/government",
    color: "bg-blue-500",
  },
  {
    icon: Newspaper,
    title: "সংবাদ মাধ্যম",
    titleEn: "News Media",
    description: "জাতীয়, বিভাগীয়, জেলা ও অনলাইন সংবাদপত্র",
    link: "/categories",
    color: "bg-red-500",
  },
  {
    icon: Tv,
    title: "টিভি চ্যানেল",
    titleEn: "TV Channels",
    description: "বাংলাদেশি ও আন্তর্জাতিক টিভি চ্যানেল",
    link: "/directory/tv",
    color: "bg-purple-500",
  },
  {
    icon: Phone,
    title: "ফোন ডিরেক্টরি",
    titleEn: "Phone Directory",
    description: "জরুরি সেবা, হাসপাতাল, পুলিশ, পরিবহন ও অন্যান্য",
    link: "/directory/phone",
    color: "bg-green-500",
  },
  {
    icon: Plane,
    title: "ভ্রমণ ও পর্যটন",
    titleEn: "Travel & Tourism",
    description: "পর্যটন স্পট, হোটেল, রিসোর্ট ও ভ্রমণ গাইড",
    link: "/directory/travel",
    color: "bg-orange-500",
  },
  {
    icon: ShoppingBag,
    title: "দৈনন্দিন জীবন",
    titleEn: "Daily Life",
    description: "অনলাইন শপিং, ফুড ডেলিভারি, রাইড শেয়ারিং ও ই-সেবা",
    link: "/directory/daily-life",
    color: "bg-pink-500",
  },
  {
    icon: Monitor,
    title: "সফটওয়্যার",
    titleEn: "Software",
    description: "উইন্ডোজ, অ্যাডোবি, ব্রাউজার ও অন্যান্য সফটওয়্যার",
    link: "/directory/software",
    color: "bg-indigo-500",
  },
  {
    icon: Share2,
    title: "সোশ্যাল মিডিয়া",
    titleEn: "Social Media",
    description: "গুগল, ফেসবুক, ইউটিউব, টুইটার ও ইমেইল সেবা",
    link: "/directory/social",
    color: "bg-cyan-500",
  },
  {
    icon: Smartphone,
    title: "অ্যাপস",
    titleEn: "Apps",
    description: "ওয়েব অ্যাপ ও অ্যান্ড্রয়েড অ্যাপ",
    link: "/directory/apps",
    color: "bg-teal-500",
  },
  {
    icon: Bot,
    title: "এআই টুলস",
    titleEn: "AI Tools",
    description: "ChatGPT, DeepSeek, Lovable ও অন্যান্য AI সেবা",
    link: "/directory/ai",
    color: "bg-violet-500",
  },
  {
    icon: Users,
    title: "ব্যক্তিত্ব",
    titleEn: "People",
    description: "জাতীয় ও আন্তর্জাতিক নেতা, সাহিত্যিক ও বিনোদন জগত",
    link: "/directory/people",
    color: "bg-amber-500",
  },
];

const Directory = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">
            বাংলাদেশ ডিরেক্টরি
          </h1>
          <p className="text-muted-foreground">
            সকল প্রয়োজনীয় লিংক এক জায়গায়
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {directoryCategories.map((category) => (
            <Link
              key={category.titleEn}
              to={category.link}
              className="group block"
            >
              <div className="bg-card border rounded-xl p-6 h-full transition-all duration-300 hover:shadow-lg hover:border-primary/50 hover:-translate-y-1">
                <div className={`${category.color} w-14 h-14 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <category.icon className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-xl font-bold mb-1">{category.title}</h2>
                <p className="text-sm text-muted-foreground mb-2">{category.titleEn}</p>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Directory;
