import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Newspaper, Plus, Pencil, Trash2, ExternalLink, Upload, Download, FileUp, Image } from 'lucide-react';
import { z } from 'zod';

interface NewspaperType {
  id: string;
  name: string;
  name_bn: string;
  url: string;
  logo_url: string | null;
  category: string;
  division: string | null;
  district: string | null;
  description: string | null;
  is_active: boolean;
  created_at: string;
}

const newspaperSchema = z.object({
  name: z.string().trim().min(1, 'নাম আবশ্যক').max(100, 'নাম ১০০ অক্ষরের বেশি হতে পারবে না'),
  name_bn: z.string().trim().min(1, 'বাংলা নাম আবশ্যক').max(100, 'বাংলা নাম ১০০ অক্ষরের বেশি হতে পারবে না'),
  url: z.string().trim().url('সঠিক URL দিন').max(500, 'URL ৫০০ অক্ষরের বেশি হতে পারবে না'),
  logo_url: z.string().trim().url('সঠিক URL দিন').max(500, 'URL ৫০০ অক্ষরের বেশি হতে পারবে না').or(z.literal('')),
  category: z.string().min(1, 'ক্যাটাগরি আবশ্যক'),
  division: z.string().max(50, 'বিভাগ ৫০ অক্ষরের বেশি হতে পারবে না').optional(),
  district: z.string().max(50, 'জেলা ৫০ অক্ষরের বেশি হতে পারবে না').optional(),
  description: z.string().max(500, 'বিবরণ ৫০০ অক্ষরের বেশি হতে পারবে না').optional(),
  is_active: z.boolean(),
});

type NewspaperFormData = z.infer<typeof newspaperSchema>;

const categories = [
  { value: 'national', label: 'জাতীয়' },
  { value: 'international', label: 'আন্তর্জাতিক' },
  { value: 'divisional', label: 'বিভাগীয়' },
  { value: 'district', label: 'জেলা' },
  { value: 'online', label: 'অনলাইন' },
];

const divisions = [
  'ঢাকা', 'চট্টগ্রাম', 'রাজশাহী', 'খুলনা', 'বরিশাল', 'সিলেট', 'রংপুর', 'ময়মনসিংহ'
];

const emptyNewspaper: NewspaperFormData = {
  name: '',
  name_bn: '',
  url: '',
  logo_url: '',
  category: 'national',
  division: '',
  district: '',
  description: '',
  is_active: true,
};

const NewspaperManagement = () => {
  const [newspapers, setNewspapers] = useState<NewspaperType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<NewspaperFormData>(emptyNewspaper);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const fetchNewspapers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('newspapers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNewspapers(data || []);
    } catch (error: any) {
      toast({
        title: 'ত্রুটি',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNewspapers();
  }, []);

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `newspapers/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('logos')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('logos')
        .getPublicUrl(filePath);

      setFormData({ ...formData, logo_url: publicUrl });
      toast({ title: 'সফল', description: 'লোগো আপলোড হয়েছে' });
    } catch (error: any) {
      toast({
        title: 'আপলোড ত্রুটি',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErrors({});

    const result = newspaperSchema.safeParse(formData);
    if (!result.success) {
      const errors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) {
          errors[err.path[0] as string] = err.message;
        }
      });
      setFormErrors(errors);
      toast({
        title: 'ভ্যালিডেশন ত্রুটি',
        description: 'ফর্মে কিছু সমস্যা আছে, অনুগ্রহ করে ঠিক করুন',
        variant: 'destructive',
      });
      return;
    }

    setSaving(true);

    try {
      const validData = result.data;
      
      if (editingId) {
        const { error } = await supabase
          .from('newspapers')
          .update({
            name: validData.name,
            name_bn: validData.name_bn,
            url: validData.url,
            logo_url: validData.logo_url || null,
            category: validData.category,
            division: validData.division || null,
            district: validData.district || null,
            description: validData.description || null,
            is_active: validData.is_active,
          })
          .eq('id', editingId);

        if (error) throw error;
        toast({ title: 'সফল', description: 'পত্রিকা আপডেট হয়েছে' });
      } else {
        const { error } = await supabase
          .from('newspapers')
          .insert({
            name: validData.name,
            name_bn: validData.name_bn,
            url: validData.url,
            logo_url: validData.logo_url || null,
            category: validData.category,
            division: validData.division || null,
            district: validData.district || null,
            description: validData.description || null,
            is_active: validData.is_active,
          });

        if (error) throw error;
        toast({ title: 'সফল', description: 'নতুন পত্রিকা যোগ হয়েছে' });
      }

      setIsDialogOpen(false);
      setEditingId(null);
      setFormData(emptyNewspaper);
      setFormErrors({});
      fetchNewspapers();
    } catch (error: any) {
      toast({
        title: 'ত্রুটি',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (newspaper: NewspaperType) => {
    setEditingId(newspaper.id);
    setFormErrors({});
    setFormData({
      name: newspaper.name,
      name_bn: newspaper.name_bn,
      url: newspaper.url,
      logo_url: newspaper.logo_url || '',
      category: newspaper.category,
      division: newspaper.division || '',
      district: newspaper.district || '',
      description: newspaper.description || '',
      is_active: newspaper.is_active,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('আপনি কি নিশ্চিত এই পত্রিকা মুছে ফেলতে চান?')) return;

    try {
      const { error } = await supabase
        .from('newspapers')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast({ title: 'সফল', description: 'পত্রিকা মুছে ফেলা হয়েছে' });
      fetchNewspapers();
    } catch (error: any) {
      toast({
        title: 'ত্রুটি',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const handleOpenDialog = () => {
    setEditingId(null);
    setFormData(emptyNewspaper);
    setFormErrors({});
    setIsDialogOpen(true);
  };

  // CSV Export
  const handleExportCSV = () => {
    const headers = ['name', 'name_bn', 'url', 'logo_url', 'category', 'division', 'district', 'description', 'is_active'];
    const csvContent = [
      headers.join(','),
      ...newspapers.map(n => 
        headers.map(h => {
          const val = n[h as keyof NewspaperType];
          if (val === null || val === undefined) return '';
          if (typeof val === 'boolean') return val ? 'true' : 'false';
          return `"${String(val).replace(/"/g, '""')}"`;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `newspapers_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast({ title: 'সফল', description: 'CSV ফাইল ডাউনলোড হয়েছে' });
  };

  // CSV Import
  const handleImportCSV = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const text = await file.text();
      const lines = text.split('\n').filter(line => line.trim());
      const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
      
      const records = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].match(/("([^"]|"")*"|[^,]*)/g) || [];
        const record: Record<string, any> = {};
        
        headers.forEach((header, idx) => {
          let val = values[idx]?.trim().replace(/^"|"$/g, '').replace(/""/g, '"') || '';
          if (header === 'is_active') {
            record[header] = val.toLowerCase() === 'true';
          } else {
            record[header] = val || null;
          }
        });
        
        if (record.name && record.name_bn && record.url) {
          records.push({
            name: record.name,
            name_bn: record.name_bn,
            url: record.url,
            logo_url: record.logo_url || null,
            category: record.category || 'national',
            division: record.division || null,
            district: record.district || null,
            description: record.description || null,
            is_active: record.is_active ?? true,
          });
        }
      }

      if (records.length === 0) {
        throw new Error('কোনো বৈধ রেকর্ড পাওয়া যায়নি');
      }

      const { error } = await supabase.from('newspapers').insert(records);
      if (error) throw error;

      toast({ title: 'সফল', description: `${records.length}টি পত্রিকা ইম্পোর্ট হয়েছে` });
      fetchNewspapers();
    } catch (error: any) {
      toast({
        title: 'ইম্পোর্ট ত্রুটি',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setImporting(false);
      if (csvInputRef.current) csvInputRef.current.value = '';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-4">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Newspaper className="h-5 w-5" />
            পত্রিকা ম্যানেজমেন্ট
          </CardTitle>
          <CardDescription>পত্রিকা যোগ, সম্পাদনা এবং মুছে ফেলুন</CardDescription>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* CSV Import */}
          <input
            type="file"
            ref={csvInputRef}
            accept=".csv"
            onChange={handleImportCSV}
            className="hidden"
          />
          <Button variant="outline" onClick={() => csvInputRef.current?.click()} disabled={importing}>
            {importing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
            CSV ইম্পোর্ট
          </Button>
          
          {/* CSV Export */}
          <Button variant="outline" onClick={handleExportCSV}>
            <Download className="h-4 w-4 mr-2" />
            CSV এক্সপোর্ট
          </Button>

          {/* Add New */}
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={handleOpenDialog}>
                <Plus className="h-4 w-4 mr-2" />
                নতুন পত্রিকা
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingId ? 'পত্রিকা সম্পাদনা' : 'নতুন পত্রিকা যোগ করুন'}</DialogTitle>
                <DialogDescription>পত্রিকার তথ্য পূরণ করুন</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">নাম (English)</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={formErrors.name ? 'border-destructive' : ''}
                      maxLength={100}
                    />
                    {formErrors.name && <p className="text-xs text-destructive">{formErrors.name}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name_bn">নাম (বাংলা)</Label>
                    <Input
                      id="name_bn"
                      value={formData.name_bn}
                      onChange={(e) => setFormData({ ...formData, name_bn: e.target.value })}
                      className={formErrors.name_bn ? 'border-destructive' : ''}
                      maxLength={100}
                    />
                    {formErrors.name_bn && <p className="text-xs text-destructive">{formErrors.name_bn}</p>}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="url">ওয়েবসাইট URL</Label>
                  <Input
                    id="url"
                    type="url"
                    value={formData.url}
                    onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                    className={formErrors.url ? 'border-destructive' : ''}
                    maxLength={500}
                    placeholder="https://example.com"
                  />
                  {formErrors.url && <p className="text-xs text-destructive">{formErrors.url}</p>}
                </div>
                
                {/* Logo Section */}
                <div className="space-y-2">
                  <Label>লোগো (120px x Auto)</Label>
                  <div className="flex gap-4 items-start">
                    <div className="flex-1 space-y-2">
                      <Input
                        id="logo_url"
                        type="url"
                        value={formData.logo_url}
                        onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                        className={formErrors.logo_url ? 'border-destructive' : ''}
                        maxLength={500}
                        placeholder="https://example.com/logo.png"
                      />
                      <div className="flex items-center gap-2">
                        <input
                          type="file"
                          ref={fileInputRef}
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => fileInputRef.current?.click()}
                          disabled={uploading}
                        >
                          {uploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FileUp className="h-4 w-4 mr-2" />}
                          লোগো আপলোড
                        </Button>
                      </div>
                    </div>
                    {formData.logo_url && (
                      <div className="w-24 h-16 border rounded flex items-center justify-center bg-muted">
                        <img
                          src={formData.logo_url}
                          alt="Preview"
                          className="max-w-[80px] h-auto max-h-14 object-contain"
                        />
                      </div>
                    )}
                  </div>
                  {formErrors.logo_url && <p className="text-xs text-destructive">{formErrors.logo_url}</p>}
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">ক্যাটাগরি</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="division">বিভাগ</Label>
                    <Select
                      value={formData.division || "none"}
                      onValueChange={(value) => setFormData({ ...formData, division: value === "none" ? "" : value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="বিভাগ নির্বাচন" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">কোনোটি নয়</SelectItem>
                        {divisions.map((div) => (
                          <SelectItem key={div} value={div}>
                            {div}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district">জেলা</Label>
                    <Input
                      id="district"
                      value={formData.district}
                      onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                      className={formErrors.district ? 'border-destructive' : ''}
                      maxLength={50}
                    />
                    {formErrors.district && <p className="text-xs text-destructive">{formErrors.district}</p>}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">বিবরণ</Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className={formErrors.description ? 'border-destructive' : ''}
                    maxLength={500}
                  />
                  {formErrors.description && <p className="text-xs text-destructive">{formErrors.description}</p>}
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">সক্রিয়</Label>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    বাতিল
                  </Button>
                  <Button type="submit" disabled={saving}>
                    {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    {editingId ? 'আপডেট করুন' : 'যোগ করুন'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>লোগো</TableHead>
              <TableHead>নাম</TableHead>
              <TableHead>ক্যাটাগরি</TableHead>
              <TableHead>বিভাগ/জেলা</TableHead>
              <TableHead>স্ট্যাটাস</TableHead>
              <TableHead>অ্যাকশন</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {newspapers.map((newspaper) => (
              <TableRow key={newspaper.id}>
                <TableCell>
                  <div className="w-16 h-10 flex items-center justify-center bg-muted rounded">
                    {newspaper.logo_url ? (
                      <img
                        src={newspaper.logo_url}
                        alt={newspaper.name}
                        className="max-w-[50px] h-auto max-h-8 object-contain"
                      />
                    ) : (
                      <Image className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{newspaper.name_bn}</p>
                    <p className="text-sm text-muted-foreground">{newspaper.name}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">
                    {categories.find(c => c.value === newspaper.category)?.label || newspaper.category}
                  </Badge>
                </TableCell>
                <TableCell>
                  {newspaper.division && <span>{newspaper.division}</span>}
                  {newspaper.district && <span className="text-muted-foreground"> / {newspaper.district}</span>}
                  {!newspaper.division && !newspaper.district && '—'}
                </TableCell>
                <TableCell>
                  <Badge variant={newspaper.is_active ? 'default' : 'secondary'}>
                    {newspaper.is_active ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" asChild>
                      <a href={newspaper.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(newspaper)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(newspaper.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {newspapers.length === 0 && (
          <p className="text-center text-muted-foreground py-4">কোনো পত্রিকা নেই। নতুন পত্রিকা যোগ করুন।</p>
        )}
      </CardContent>
    </Card>
  );
};

export default NewspaperManagement;