import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Pencil, Trash2, Loader2, FolderOpen, Layers } from 'lucide-react';

interface DirectoryCategory {
  id: string;
  slug: string;
  name_bn: string;
  name_en: string;
  description: string | null;
  icon: string | null;
  color: string | null;
  sort_order: number | null;
  is_active: boolean;
}

interface DirectoryItem {
  id: string;
  category_id: string;
  subcategory: string | null;
  name_bn: string;
  name_en: string | null;
  url: string | null;
  phone: string | null;
  description: string | null;
  sort_order: number | null;
  is_active: boolean;
}

const DirectoryManagement = () => {
  const { toast } = useToast();
  const [categories, setCategories] = useState<DirectoryCategory[]>([]);
  const [items, setItems] = useState<DirectoryItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Item dialog state
  const [itemDialogOpen, setItemDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<DirectoryItem | null>(null);
  const [itemFormData, setItemFormData] = useState({
    category_id: '',
    subcategory: '',
    name_bn: '',
    name_en: '',
    url: '',
    phone: '',
    description: '',
  });

  // Category dialog state
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<DirectoryCategory | null>(null);
  const [categoryFormData, setCategoryFormData] = useState({
    slug: '',
    name_bn: '',
    name_en: '',
    description: '',
    icon: '',
    color: 'bg-blue-500',
    sort_order: 0,
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      fetchItems(selectedCategory);
    }
  }, [selectedCategory]);

  const fetchCategories = async () => {
    const { data, error } = await supabase
      .from('directory_categories')
      .select('*')
      .order('sort_order');
    
    if (error) {
      console.error('Error fetching categories:', error);
      return;
    }
    
    setCategories(data || []);
    setLoading(false);
  };

  const fetchItems = async (categoryId: string) => {
    const { data, error } = await supabase
      .from('directory_items')
      .select('*')
      .eq('category_id', categoryId)
      .order('subcategory')
      .order('sort_order');
    
    if (error) {
      console.error('Error fetching items:', error);
      return;
    }
    
    setItems(data || []);
  };

  // Category CRUD
  const handleCategorySubmit = async () => {
    if (!categoryFormData.name_bn || !categoryFormData.name_en || !categoryFormData.slug) {
      toast({ title: 'ত্রুটি', description: 'প্রয়োজনীয় তথ্য পূরণ করুন', variant: 'destructive' });
      return;
    }

    const categoryData = {
      slug: categoryFormData.slug,
      name_bn: categoryFormData.name_bn,
      name_en: categoryFormData.name_en,
      description: categoryFormData.description || null,
      icon: categoryFormData.icon || null,
      color: categoryFormData.color || 'bg-blue-500',
      sort_order: categoryFormData.sort_order,
    };

    if (editingCategory) {
      const { error } = await supabase
        .from('directory_categories')
        .update(categoryData)
        .eq('id', editingCategory.id);

      if (error) {
        toast({ title: 'ত্রুটি', description: 'ক্যাটাগরি আপডেট করতে সমস্যা হয়েছে', variant: 'destructive' });
        return;
      }
      toast({ title: 'সফল', description: 'ক্যাটাগরি আপডেট হয়েছে' });
    } else {
      const { error } = await supabase
        .from('directory_categories')
        .insert(categoryData);

      if (error) {
        toast({ title: 'ত্রুটি', description: 'ক্যাটাগরি যোগ করতে সমস্যা হয়েছে', variant: 'destructive' });
        return;
      }
      toast({ title: 'সফল', description: 'নতুন ক্যাটাগরি যোগ হয়েছে' });
    }

    setCategoryDialogOpen(false);
    resetCategoryForm();
    fetchCategories();
  };

  const handleCategoryDelete = async (id: string) => {
    if (!confirm('আপনি কি এই ক্যাটাগরি মুছে ফেলতে চান? এর সাথে সম্পর্কিত সব আইটেমও মুছে যাবে।')) return;

    const { error } = await supabase
      .from('directory_categories')
      .delete()
      .eq('id', id);

    if (error) {
      toast({ title: 'ত্রুটি', description: 'ক্যাটাগরি মুছতে সমস্যা হয়েছে', variant: 'destructive' });
      return;
    }

    toast({ title: 'সফল', description: 'ক্যাটাগরি মুছে ফেলা হয়েছে' });
    fetchCategories();
  };

  const openEditCategoryDialog = (category: DirectoryCategory) => {
    setEditingCategory(category);
    setCategoryFormData({
      slug: category.slug,
      name_bn: category.name_bn,
      name_en: category.name_en,
      description: category.description || '',
      icon: category.icon || '',
      color: category.color || 'bg-blue-500',
      sort_order: category.sort_order || 0,
    });
    setCategoryDialogOpen(true);
  };

  const resetCategoryForm = () => {
    setEditingCategory(null);
    setCategoryFormData({
      slug: '',
      name_bn: '',
      name_en: '',
      description: '',
      icon: '',
      color: 'bg-blue-500',
      sort_order: 0,
    });
  };

  // Item CRUD
  const handleItemSubmit = async () => {
    if (!itemFormData.name_bn || !itemFormData.category_id) {
      toast({ title: 'ত্রুটি', description: 'প্রয়োজনীয় তথ্য পূরণ করুন', variant: 'destructive' });
      return;
    }

    const itemData = {
      category_id: itemFormData.category_id,
      subcategory: itemFormData.subcategory || null,
      name_bn: itemFormData.name_bn,
      name_en: itemFormData.name_en || null,
      url: itemFormData.url || null,
      phone: itemFormData.phone || null,
      description: itemFormData.description || null,
    };

    if (editingItem) {
      const { error } = await supabase
        .from('directory_items')
        .update(itemData)
        .eq('id', editingItem.id);

      if (error) {
        toast({ title: 'ত্রুটি', description: 'আইটেম আপডেট করতে সমস্যা হয়েছে', variant: 'destructive' });
        return;
      }
      toast({ title: 'সফল', description: 'আইটেম আপডেট হয়েছে' });
    } else {
      const { error } = await supabase
        .from('directory_items')
        .insert(itemData);

      if (error) {
        toast({ title: 'ত্রুটি', description: 'আইটেম যোগ করতে সমস্যা হয়েছে', variant: 'destructive' });
        return;
      }
      toast({ title: 'সফল', description: 'নতুন আইটেম যোগ হয়েছে' });
    }

    setItemDialogOpen(false);
    resetItemForm();
    if (selectedCategory) fetchItems(selectedCategory);
  };

  const handleItemDelete = async (id: string) => {
    if (!confirm('আপনি কি এই আইটেম মুছে ফেলতে চান?')) return;

    const { error } = await supabase
      .from('directory_items')
      .delete()
      .eq('id', id);

    if (error) {
      toast({ title: 'ত্রুটি', description: 'আইটেম মুছতে সমস্যা হয়েছে', variant: 'destructive' });
      return;
    }

    toast({ title: 'সফল', description: 'আইটেম মুছে ফেলা হয়েছে' });
    if (selectedCategory) fetchItems(selectedCategory);
  };

  const openEditItemDialog = (item: DirectoryItem) => {
    setEditingItem(item);
    setItemFormData({
      category_id: item.category_id,
      subcategory: item.subcategory || '',
      name_bn: item.name_bn,
      name_en: item.name_en || '',
      url: item.url || '',
      phone: item.phone || '',
      description: item.description || '',
    });
    setItemDialogOpen(true);
  };

  const resetItemForm = () => {
    setEditingItem(null);
    setItemFormData({
      category_id: selectedCategory || '',
      subcategory: '',
      name_bn: '',
      name_en: '',
      url: '',
      phone: '',
      description: '',
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="items">
        <TabsList>
          <TabsTrigger value="items" className="flex items-center gap-2">
            <FolderOpen className="h-4 w-4" />
            আইটেম ম্যানেজমেন্ট
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center gap-2">
            <Layers className="h-4 w-4" />
            ক্যাটাগরি ম্যানেজমেন্ট
          </TabsTrigger>
        </TabsList>

        {/* Items Tab */}
        <TabsContent value="items">
          <Card>
            <CardHeader>
              <CardTitle>ডিরেক্টরি আইটেম</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex-1 min-w-[200px]">
                  <Label>ক্যাটাগরি নির্বাচন করুন</Label>
                  <Select value={selectedCategory || ''} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="ক্যাটাগরি নির্বাচন করুন" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.name_bn} ({cat.name_en})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Dialog open={itemDialogOpen} onOpenChange={(open) => { setItemDialogOpen(open); if (!open) resetItemForm(); }}>
                    <DialogTrigger asChild>
                      <Button disabled={!selectedCategory} onClick={() => { resetItemForm(); setItemFormData(prev => ({ ...prev, category_id: selectedCategory || '' })); }}>
                        <Plus className="h-4 w-4 mr-2" />
                        নতুন আইটেম
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{editingItem ? 'আইটেম সম্পাদনা' : 'নতুন আইটেম যোগ'}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>ক্যাটাগরি</Label>
                          <Select value={itemFormData.category_id} onValueChange={(v) => setItemFormData({ ...itemFormData, category_id: v })}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {categories.map((cat) => (
                                <SelectItem key={cat.id} value={cat.id}>{cat.name_bn}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>সাবক্যাটাগরি</Label>
                          <Input
                            value={itemFormData.subcategory}
                            onChange={(e) => setItemFormData({ ...itemFormData, subcategory: e.target.value })}
                            placeholder="যেমন: জরুরি সেবা, মন্ত্রণালয়"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>নাম (বাংলা) *</Label>
                            <Input
                              value={itemFormData.name_bn}
                              onChange={(e) => setItemFormData({ ...itemFormData, name_bn: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>নাম (English)</Label>
                            <Input
                              value={itemFormData.name_en}
                              onChange={(e) => setItemFormData({ ...itemFormData, name_en: e.target.value })}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>URL</Label>
                          <Input
                            value={itemFormData.url}
                            onChange={(e) => setItemFormData({ ...itemFormData, url: e.target.value })}
                            placeholder="https://example.com"
                          />
                        </div>
                        <div>
                          <Label>ফোন নম্বর</Label>
                          <Input
                            value={itemFormData.phone}
                            onChange={(e) => setItemFormData({ ...itemFormData, phone: e.target.value })}
                            placeholder="999"
                          />
                        </div>
                        <div>
                          <Label>বিবরণ</Label>
                          <Textarea
                            value={itemFormData.description}
                            onChange={(e) => setItemFormData({ ...itemFormData, description: e.target.value })}
                            rows={2}
                          />
                        </div>
                        <Button onClick={handleItemSubmit} className="w-full">
                          {editingItem ? 'আপডেট করুন' : 'যোগ করুন'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {selectedCategory && (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>নাম</TableHead>
                        <TableHead>সাবক্যাটাগরি</TableHead>
                        <TableHead>URL/ফোন</TableHead>
                        <TableHead className="w-[100px]">অ্যাকশন</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                            কোনো আইটেম নেই
                          </TableCell>
                        </TableRow>
                      ) : (
                        items.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div>
                                <p className="font-medium">{item.name_bn}</p>
                                {item.name_en && <p className="text-xs text-muted-foreground">{item.name_en}</p>}
                              </div>
                            </TableCell>
                            <TableCell>{item.subcategory || '-'}</TableCell>
                            <TableCell className="text-sm">
                              {item.url && <a href={item.url} target="_blank" className="text-primary hover:underline block truncate max-w-[200px]">{item.url}</a>}
                              {item.phone && <span>{item.phone}</span>}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="icon" onClick={() => openEditItemDialog(item)}>
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => handleItemDelete(item.id)}>
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>ডিরেক্টরি ক্যাটাগরি</CardTitle>
              <Dialog open={categoryDialogOpen} onOpenChange={(open) => { setCategoryDialogOpen(open); if (!open) resetCategoryForm(); }}>
                <DialogTrigger asChild>
                  <Button onClick={resetCategoryForm}>
                    <Plus className="h-4 w-4 mr-2" />
                    নতুন ক্যাটাগরি
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingCategory ? 'ক্যাটাগরি সম্পাদনা' : 'নতুন ক্যাটাগরি যোগ'}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>নাম (বাংলা) *</Label>
                        <Input
                          value={categoryFormData.name_bn}
                          onChange={(e) => setCategoryFormData({ ...categoryFormData, name_bn: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>নাম (English) *</Label>
                        <Input
                          value={categoryFormData.name_en}
                          onChange={(e) => setCategoryFormData({ ...categoryFormData, name_en: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Slug *</Label>
                      <Input
                        value={categoryFormData.slug}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, slug: e.target.value })}
                        placeholder="government, phone, travel"
                      />
                    </div>
                    <div>
                      <Label>বিবরণ</Label>
                      <Textarea
                        value={categoryFormData.description}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, description: e.target.value })}
                        rows={2}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>আইকন</Label>
                        <Input
                          value={categoryFormData.icon}
                          onChange={(e) => setCategoryFormData({ ...categoryFormData, icon: e.target.value })}
                          placeholder="Globe, Phone, Map"
                        />
                      </div>
                      <div>
                        <Label>কালার ক্লাস</Label>
                        <Input
                          value={categoryFormData.color}
                          onChange={(e) => setCategoryFormData({ ...categoryFormData, color: e.target.value })}
                          placeholder="bg-blue-500"
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Sort Order</Label>
                      <Input
                        type="number"
                        value={categoryFormData.sort_order}
                        onChange={(e) => setCategoryFormData({ ...categoryFormData, sort_order: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                    <Button onClick={handleCategorySubmit} className="w-full">
                      {editingCategory ? 'আপডেট করুন' : 'যোগ করুন'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>নাম</TableHead>
                      <TableHead>Slug</TableHead>
                      <TableHead>Sort</TableHead>
                      <TableHead className="w-[100px]">অ্যাকশন</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categories.map((cat) => (
                      <TableRow key={cat.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{cat.name_bn}</p>
                            <p className="text-xs text-muted-foreground">{cat.name_en}</p>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">{cat.slug}</TableCell>
                        <TableCell>{cat.sort_order}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" onClick={() => openEditCategoryDialog(cat)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleCategoryDelete(cat.id)}>
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DirectoryManagement;
