import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Rss, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

interface NewsSource {
  id: string;
  name: string;
  name_bn: string;
  website_url: string | null;
  rss_feed_url: string | null;
  logo_url: string | null;
  category: string;
  is_active: boolean | null;
  is_featured: boolean | null;
  sort_order: number | null;
}

const categories = [
  { value: 'national', label: 'জাতীয়' },
  { value: 'international', label: 'আন্তর্জাতিক' },
  { value: 'sports', label: 'খেলাধুলা' },
  { value: 'entertainment', label: 'বিনোদন' },
  { value: 'business', label: 'ব্যবসা' },
  { value: 'technology', label: 'প্রযুক্তি' },
];

const NewsSourcesManagement = () => {
  const [sources, setSources] = useState<NewsSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSource, setEditingSource] = useState<NewsSource | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    name_bn: '',
    website_url: '',
    rss_feed_url: '',
    logo_url: '',
    category: 'national',
    is_active: true,
    is_featured: false,
    sort_order: 0,
  });

  const fetchSources = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('news_sources')
      .select('*')
      .order('sort_order', { ascending: true });

    if (error) {
      toast.error('নিউজ সোর্স লোড করতে সমস্যা হয়েছে');
      console.error(error);
    } else {
      setSources(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSources();
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      name_bn: '',
      website_url: '',
      rss_feed_url: '',
      logo_url: '',
      category: 'national',
      is_active: true,
      is_featured: false,
      sort_order: 0,
    });
    setEditingSource(null);
  };

  const handleEdit = (source: NewsSource) => {
    setEditingSource(source);
    setFormData({
      name: source.name,
      name_bn: source.name_bn,
      website_url: source.website_url || '',
      rss_feed_url: source.rss_feed_url || '',
      logo_url: source.logo_url || '',
      category: source.category,
      is_active: source.is_active ?? true,
      is_featured: source.is_featured ?? false,
      sort_order: source.sort_order ?? 0,
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.name_bn) {
      toast.error('নাম এবং বাংলা নাম আবশ্যক');
      return;
    }

    const payload = {
      name: formData.name,
      name_bn: formData.name_bn,
      website_url: formData.website_url || null,
      rss_feed_url: formData.rss_feed_url || null,
      logo_url: formData.logo_url || null,
      category: formData.category,
      is_active: formData.is_active,
      is_featured: formData.is_featured,
      sort_order: formData.sort_order,
    };

    if (editingSource) {
      const { error } = await supabase
        .from('news_sources')
        .update(payload)
        .eq('id', editingSource.id);

      if (error) {
        toast.error('আপডেট করতে সমস্যা হয়েছে');
        console.error(error);
      } else {
        toast.success('নিউজ সোর্স আপডেট হয়েছে');
        fetchSources();
        setDialogOpen(false);
        resetForm();
      }
    } else {
      const { error } = await supabase
        .from('news_sources')
        .insert([payload]);

      if (error) {
        toast.error('যোগ করতে সমস্যা হয়েছে');
        console.error(error);
      } else {
        toast.success('নিউজ সোর্স যোগ হয়েছে');
        fetchSources();
        setDialogOpen(false);
        resetForm();
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('আপনি কি নিশ্চিত এই নিউজ সোর্স মুছে ফেলতে চান?')) return;

    const { error } = await supabase
      .from('news_sources')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('মুছে ফেলতে সমস্যা হয়েছে');
      console.error(error);
    } else {
      toast.success('নিউজ সোর্স মুছে ফেলা হয়েছে');
      fetchSources();
    }
  };

  const toggleActive = async (source: NewsSource) => {
    const { error } = await supabase
      .from('news_sources')
      .update({ is_active: !source.is_active })
      .eq('id', source.id);

    if (error) {
      toast.error('স্ট্যাটাস পরিবর্তন করতে সমস্যা হয়েছে');
    } else {
      fetchSources();
    }
  };

  const toggleFeatured = async (source: NewsSource) => {
    const { error } = await supabase
      .from('news_sources')
      .update({ is_featured: !source.is_featured })
      .eq('id', source.id);

    if (error) {
      toast.error('ফিচার্ড স্ট্যাটাস পরিবর্তন করতে সমস্যা হয়েছে');
    } else {
      fetchSources();
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Rss className="h-5 w-5" />
          নিউজ সোর্স ম্যানেজমেন্ট
        </CardTitle>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              নতুন সোর্স যোগ করুন
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingSource ? 'নিউজ সোর্স সম্পাদনা' : 'নতুন নিউজ সোর্স যোগ'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">নাম (English)</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Prothom Alo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name_bn">নাম (বাংলা)</Label>
                  <Input
                    id="name_bn"
                    value={formData.name_bn}
                    onChange={(e) => setFormData({ ...formData, name_bn: e.target.value })}
                    placeholder="প্রথম আলো"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website_url">ওয়েবসাইট URL</Label>
                <Input
                  id="website_url"
                  type="url"
                  value={formData.website_url}
                  onChange={(e) => setFormData({ ...formData, website_url: e.target.value })}
                  placeholder="https://www.prothomalo.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rss_feed_url">RSS ফিড URL</Label>
                <Input
                  id="rss_feed_url"
                  type="url"
                  value={formData.rss_feed_url}
                  onChange={(e) => setFormData({ ...formData, rss_feed_url: e.target.value })}
                  placeholder="https://www.prothomalo.com/feed"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo_url">লোগো URL</Label>
                <Input
                  id="logo_url"
                  type="url"
                  value={formData.logo_url}
                  onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                  placeholder="https://example.com/logo.png"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">ক্যাটাগরি</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sort_order">সর্ট অর্ডার</Label>
                  <Input
                    id="sort_order"
                    type="number"
                    value={formData.sort_order}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">সক্রিয়</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="is_featured"
                    checked={formData.is_featured}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_featured: checked })}
                  />
                  <Label htmlFor="is_featured">ফিচার্ড</Label>
                </div>
              </div>

              <Button type="submit" className="w-full">
                {editingSource ? 'আপডেট করুন' : 'যোগ করুন'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : sources.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            কোনো নিউজ সোর্স নেই
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>নাম</TableHead>
                  <TableHead>ক্যাটাগরি</TableHead>
                  <TableHead>RSS ফিড</TableHead>
                  <TableHead>সক্রিয়</TableHead>
                  <TableHead>ফিচার্ড</TableHead>
                  <TableHead className="text-right">অ্যাকশন</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sources.map((source) => (
                  <TableRow key={source.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{source.name_bn}</div>
                        <div className="text-sm text-muted-foreground">{source.name}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {categories.find(c => c.value === source.category)?.label || source.category}
                    </TableCell>
                    <TableCell>
                      {source.rss_feed_url ? (
                        <a
                          href={source.rss_feed_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-primary hover:underline"
                        >
                          <Rss className="h-3 w-3" />
                          RSS
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={source.is_active ?? false}
                        onCheckedChange={() => toggleActive(source)}
                      />
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={source.is_featured ?? false}
                        onCheckedChange={() => toggleFeatured(source)}
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(source)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(source.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default NewsSourcesManagement;
