import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Settings, Save, Globe, Mail, Phone, MapPin, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface GeneralSettings {
  siteName: string;
  siteNameEn: string;
  tagline: string;
  description: string;
}

interface ContactSettings {
  email: string;
  phone: string;
  address: string;
}

interface SocialSettings {
  facebook: string;
  twitter: string;
  youtube: string;
  linkedin: string;
}

interface FeatureSettings {
  enableNewsletter: boolean;
  enableSubmissions: boolean;
  enableComments: boolean;
  maintenanceMode: boolean;
}

const SiteSettings = () => {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const [general, setGeneral] = useState<GeneralSettings>({
    siteName: '',
    siteNameEn: '',
    tagline: '',
    description: '',
  });

  const [contact, setContact] = useState<ContactSettings>({
    email: '',
    phone: '',
    address: '',
  });

  const [social, setSocial] = useState<SocialSettings>({
    facebook: '',
    twitter: '',
    youtube: '',
    linkedin: '',
  });

  const [features, setFeatures] = useState<FeatureSettings>({
    enableNewsletter: true,
    enableSubmissions: true,
    enableComments: false,
    maintenanceMode: false,
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value');
      
      if (error) throw error;

      data?.forEach((setting) => {
        const value = setting.value as Record<string, unknown>;
        switch (setting.key) {
          case 'general':
            setGeneral(value as unknown as GeneralSettings);
            break;
          case 'contact':
            setContact(value as unknown as ContactSettings);
            break;
          case 'social':
            setSocial(value as unknown as SocialSettings);
            break;
          case 'features':
            setFeatures(value as unknown as FeatureSettings);
            break;
        }
      });
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates = [
        { key: 'general', value: JSON.parse(JSON.stringify(general)) },
        { key: 'contact', value: JSON.parse(JSON.stringify(contact)) },
        { key: 'social', value: JSON.parse(JSON.stringify(social)) },
        { key: 'features', value: JSON.parse(JSON.stringify(features)) },
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('site_settings')
          .update({ value: update.value })
          .eq('key', update.key);
        
        if (error) throw error;
      }

      toast({
        title: 'সফল',
        description: 'সেটিংস সংরক্ষিত হয়েছে',
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'ত্রুটি',
        description: 'সেটিংস সংরক্ষণ করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            সাধারণ সেটিংস
          </CardTitle>
          <CardDescription>সাইটের মৌলিক তথ্য</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="siteName">সাইটের নাম (বাংলা)</Label>
              <Input
                id="siteName"
                value={general.siteName}
                onChange={(e) => setGeneral({ ...general, siteName: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="siteNameEn">সাইটের নাম (English)</Label>
              <Input
                id="siteNameEn"
                value={general.siteNameEn}
                onChange={(e) => setGeneral({ ...general, siteNameEn: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="tagline">ট্যাগলাইন</Label>
            <Input
              id="tagline"
              value={general.tagline}
              onChange={(e) => setGeneral({ ...general, tagline: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">বিবরণ</Label>
            <Textarea
              id="description"
              value={general.description}
              onChange={(e) => setGeneral({ ...general, description: e.target.value })}
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Contact Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            যোগাযোগ তথ্য
          </CardTitle>
          <CardDescription>সাইটের যোগাযোগ তথ্য</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                ইমেইল
              </Label>
              <Input
                id="email"
                type="email"
                value={contact.email}
                onChange={(e) => setContact({ ...contact, email: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                ফোন
              </Label>
              <Input
                id="phone"
                value={contact.phone}
                onChange={(e) => setContact({ ...contact, phone: e.target.value })}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="address" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              ঠিকানা
            </Label>
            <Input
              id="address"
              value={contact.address}
              onChange={(e) => setContact({ ...contact, address: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Social Media Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            সোশ্যাল মিডিয়া
          </CardTitle>
          <CardDescription>সোশ্যাল মিডিয়া লিংক</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="facebook">Facebook URL</Label>
            <Input
              id="facebook"
              type="url"
              placeholder="https://facebook.com/yourpage"
              value={social.facebook}
              onChange={(e) => setSocial({ ...social, facebook: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="twitter">Twitter URL</Label>
            <Input
              id="twitter"
              type="url"
              placeholder="https://twitter.com/yourhandle"
              value={social.twitter}
              onChange={(e) => setSocial({ ...social, twitter: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="youtube">YouTube URL</Label>
            <Input
              id="youtube"
              type="url"
              placeholder="https://youtube.com/yourchannel"
              value={social.youtube}
              onChange={(e) => setSocial({ ...social, youtube: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Feature Toggles */}
      <Card>
        <CardHeader>
          <CardTitle>ফিচার সেটিংস</CardTitle>
          <CardDescription>সাইটের বিভিন্ন ফিচার অন/অফ করুন</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">মেইনটেন্যান্স মোড</p>
              <p className="text-sm text-muted-foreground">সাইট সাময়িকভাবে বন্ধ রাখুন</p>
            </div>
            <Switch
              checked={features.maintenanceMode}
              onCheckedChange={(checked) => setFeatures({ ...features, maintenanceMode: checked })}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">পত্রিকা সাবমিশন</p>
              <p className="text-sm text-muted-foreground">ব্যবহারকারীরা নতুন পত্রিকা জমা দিতে পারবে</p>
            </div>
            <Switch
              checked={features.enableSubmissions}
              onCheckedChange={(checked) => setFeatures({ ...features, enableSubmissions: checked })}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">নিউজলেটার</p>
              <p className="text-sm text-muted-foreground">নিউজলেটার সাবস্ক্রিপশন চালু করুন</p>
            </div>
            <Switch
              checked={features.enableNewsletter}
              onCheckedChange={(checked) => setFeatures({ ...features, enableNewsletter: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          {saving ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}
        </Button>
      </div>
    </div>
  );
};

export default SiteSettings;
