import { Link } from "react-router-dom";
import { Facebook, Twitter, Youtube, Mail, Phone } from "lucide-react";

const Footer = () => {
  const quickLinks = [
    { name: "হোম", path: "/" },
    { name: "ডিরেক্টরি", path: "/directory" },
    { name: "ক্যাটাগরি", path: "/categories" },
    { name: "বিভাগীয় পত্রিকা", path: "/division-newspapers" },
  ];

  const directoryLinks = [
    { name: "সরকারি সাইট", path: "/directory/government" },
    { name: "ফোন নম্বর", path: "/directory/phone" },
    { name: "ভ্রমণ ও পর্যটন", path: "/directory/travel" },
    { name: "দৈনন্দিন জীবন", path: "/directory/daily-life" },
    { name: "সামাজিক মাধ্যম", path: "/directory/social" },
  ];

  const socialLinks = [
    { icon: Facebook, href: "https://facebook.com", label: "Facebook" },
    { icon: Twitter, href: "https://twitter.com", label: "Twitter" },
    { icon: Youtube, href: "https://youtube.com", label: "YouTube" },
  ];

  return (
    <footer className="bg-primary text-primary-foreground mt-12">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <h3 className="text-lg font-bold mb-4">আমাদের সম্পর্কে</h3>
            <p className="text-sm leading-relaxed opacity-90">
              বাংলাদেশের সকল সংবাদপত্র, অনলাইন নিউজ পোর্টাল এবং গুরুত্বপূর্ণ ওয়েবসাইটের একটি সম্পূর্ণ তালিকা। 
              আমরা বাংলাদেশী পাঠকদের জন্য সহজে তথ্য খুঁজে পেতে সাহায্য করি।
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">দ্রুত লিংক</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm opacity-90 hover:opacity-100 hover:underline transition-opacity"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Directory Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">ডিরেক্টরি</h3>
            <ul className="space-y-2">
              {directoryLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm opacity-90 hover:opacity-100 hover:underline transition-opacity"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Social */}
          <div>
            <h3 className="text-lg font-bold mb-4">যোগাযোগ</h3>
            <div className="space-y-3">
              <a
                href="mailto:info@allbanglanewspapers.com"
                className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
              >
                <Mail size={16} />
                info@allbanglanewspapers.com
              </a>
              <a
                href="tel:+8801700000000"
                className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100 transition-opacity"
              >
                <Phone size={16} />
                +880 1700-000000
              </a>
            </div>

            <h4 className="text-sm font-bold mt-6 mb-3">সামাজিক মাধ্যম</h4>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-primary-foreground/10 rounded-full hover:bg-primary-foreground/20 transition-colors"
                  aria-label={social.label}
                >
                  <social.icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 mt-8 pt-6 text-center">
          <p className="text-sm opacity-80">
            © {new Date().getFullYear()} All Bangla Newspapers. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
