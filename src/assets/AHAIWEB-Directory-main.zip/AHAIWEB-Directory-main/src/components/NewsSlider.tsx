import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Loader2, ExternalLink } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { supabase } from "@/integrations/supabase/client";

interface RSSItem {
  title: string;
  link: string;
  source: string;
  source_bn: string;
  source_logo: string | null;
  pubDate: string;
}

interface NewsSliderProps {
  autoPlayInterval?: number;
}

const NewsSlider = ({ autoPlayInterval = 5000 }: NewsSliderProps) => {
  const [newsItems, setNewsItems] = useState<RSSItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('fetch-rss-feeds');
        if (error) throw error;
        if (data?.items) {
          setNewsItems(data.items.slice(0, 20));
        }
      } catch (error) {
        console.error('Error fetching news:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, []);

  useEffect(() => {
    if (newsItems.length <= 1) return;
    
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % newsItems.length);
    }, autoPlayInterval);

    return () => clearInterval(timer);
  }, [newsItems.length, autoPlayInterval]);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + newsItems.length) % newsItems.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % newsItems.length);
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-r from-primary/5 to-accent/5 py-8 px-4 rounded-lg">
        <div className="flex items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <span className="ml-2 text-sm text-muted-foreground">নিউজ লোড হচ্ছে...</span>
        </div>
      </div>
    );
  }

  if (newsItems.length === 0) return null;

  // Show 3 items at a time
  const visibleCount = 3;
  const visibleItems: RSSItem[] = [];
  for (let i = 0; i < Math.min(visibleCount, newsItems.length); i++) {
    const index = (currentIndex + i) % newsItems.length;
    visibleItems.push(newsItems[index]);
  }

  const formatTimeAgo = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 60) return `${diffMins} মিনিট আগে`;
      if (diffHours < 24) return `${diffHours} ঘণ্টা আগে`;
      return `${diffDays} দিন আগে`;
    } catch {
      return '';
    }
  };

  return (
    <div className="relative bg-gradient-to-r from-primary/5 to-accent/5 py-6 px-4 rounded-lg">
      <div className="flex items-center gap-2 mb-4">
        <span className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded">
          সর্বশেষ খবর
        </span>
        <div className="h-px flex-1 bg-border" />
      </div>

      <div className="flex items-center justify-between gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={goToPrevious}
          className="shrink-0 rounded-full"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <div className="flex-1 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {visibleItems.map((item, idx) => (
              <a
                key={`${item.link}-${idx}`}
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                className="block group"
              >
                <Card className="p-4 h-full hover:shadow-lg transition-all duration-300 border group-hover:border-primary bg-card">
                  <div className="flex items-start gap-3">
                    {item.source_logo && (
                      <div className="w-10 h-10 flex items-center justify-center bg-muted rounded shrink-0">
                        <img
                          src={item.source_logo}
                          alt={item.source}
                          className="max-w-[32px] h-auto max-h-8 object-contain"
                        />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground group-hover:text-primary line-clamp-2 leading-snug">
                        {item.title}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-primary font-medium">
                          {item.source_bn}
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          {formatTimeAgo(item.pubDate)}
                        </span>
                      </div>
                    </div>
                    <ExternalLink className="h-3 w-3 text-muted-foreground group-hover:text-primary shrink-0 mt-1" />
                  </div>
                </Card>
              </a>
            ))}
          </div>
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={goToNext}
          className="shrink-0 rounded-full"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Dots indicator */}
      <div className="flex justify-center gap-1 mt-4">
        {Array.from({ length: Math.ceil(newsItems.length / visibleCount) }).map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx * visibleCount)}
            className={`w-2 h-2 rounded-full transition-colors ${
              Math.floor(currentIndex / visibleCount) === idx ? 'bg-primary' : 'bg-muted-foreground/30'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default NewsSlider;
