import { Card } from "./ui/card";

interface NewspaperCardProps {
  name: string;
  logo: string;
  link?: string;
}

const NewspaperCard = ({ name, logo, link = "#" }: NewspaperCardProps) => {
  return (
    <a 
      href={link} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="block group"
    >
      <Card className="p-4 hover:shadow-lg transition-all duration-300 border-2 group-hover:border-primary h-full flex flex-col items-center justify-center gap-3">
        <div className="w-full h-16 flex items-center justify-center">
          <img
            src={logo}
            alt={name}
            style={{ width: '120px', height: 'auto', maxHeight: '100%' }}
            className="object-contain"
          />
        </div>
        <h3 className="text-center text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
          {name}
        </h3>
      </Card>
    </a>
  );
};

export default NewspaperCard;
