import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Rss, ExternalLink, Star, BookOpen, Loader2, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Newspaper {
  id: string;
  name_bn: string;
  logo_url: string | null;
  url: string;
}

interface RSSItem {
  title: string;
  link: string;
  source_bn: string;
  pubDate: string;
}

const RightSidebar = () => {
  const [featuredPapers, setFeaturedPapers] = useState<Newspaper[]>([]);
  const [rssItems, setRssItems] = useState<RSSItem[]>([]);
  const [loadingRss, setLoadingRss] = useState(false);

  const fetchRSSFeeds = async () => {
    setLoadingRss(true);
    try {
      const { data, error } = await supabase.functions.invoke('fetch-rss-feeds');
      
      if (error) throw error;
      
      if (data?.items) {
        setRssItems(data.items.slice(0, 8));
      }
    } catch (error) {
      console.error('Error fetching RSS:', error);
    } finally {
      setLoadingRss(false);
    }
  };

  useEffect(() => {
    const fetchFeatured = async () => {
      const { data } = await supabase
        .from('newspapers')
        .select('id, name_bn, logo_url, url')
        .eq('is_active', true)
        .eq('category', 'national')
        .limit(5);

      if (data) {
        setFeaturedPapers(data);
      }
    };

    fetchFeatured();
    fetchRSSFeeds();

    // Auto-refresh RSS every 5 minutes
    const intervalId = setInterval(fetchRSSFeeds, 5 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  return (
    <aside className="space-y-6">
      {/* RSS Feed Info */}
      <Card className="bg-gradient-to-br from-primary/10 to-accent/5">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Rss className="h-4 w-4 text-primary" />
            RSS ফিড
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {rssItems.length > 0 ? (
            <div className="space-y-2">
              {rssItems.map((item, idx) => (
                <a
                  key={idx}
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-2 rounded hover:bg-muted transition-colors"
                >
                  <p className="text-xs font-medium line-clamp-2 hover:text-primary">
                    {item.title}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {item.source_bn}
                  </p>
                </a>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              আপনার প্রিয় সংবাদ সোর্সগুলোর RSS ফিড দেখুন
            </p>
          )}
          <Button 
            size="sm" 
            variant="outline" 
            className="w-full"
            onClick={fetchRSSFeeds}
            disabled={loadingRss}
          >
            {loadingRss ? (
              <Loader2 className="h-3 w-3 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-3 w-3 mr-2" />
            )}
            {rssItems.length > 0 ? 'রিফ্রেশ করুন' : 'ফিড লোড করুন'}
          </Button>
        </CardContent>
      </Card>

      {/* Featured Papers */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Star className="h-4 w-4 text-primary" />
            বৈশিষ্ট্যযুক্ত পত্রিকা
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {featuredPapers.map((paper) => (
            <a
              key={paper.id}
              href={paper.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors group"
            >
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <div className="w-8 h-8 flex items-center justify-center bg-background rounded border shrink-0">
                  <img
                    src={paper.logo_url || '/placeholder.svg'}
                    alt={paper.name_bn}
                    className="max-w-[24px] h-auto max-h-6 object-contain"
                  />
                </div>
                <span className="text-xs font-medium group-hover:text-primary truncate">
                  {paper.name_bn}
                </span>
              </div>
              <ExternalLink className="h-3 w-3 text-muted-foreground group-hover:text-primary shrink-0" />
            </a>
          ))}
        </CardContent>
      </Card>

      {/* Quick Links */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-primary" />
            দ্রুত লিংক
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <a href="/directory" className="block text-xs text-muted-foreground hover:text-primary transition-colors">
            → ডিরেক্টরি
          </a>
          <a href="/categories" className="block text-xs text-muted-foreground hover:text-primary transition-colors">
            → ক্যাটাগরি
          </a>
          <a href="/division-newspapers" className="block text-xs text-muted-foreground hover:text-primary transition-colors">
            → বিভাগীয় পত্রিকা
          </a>
        </CardContent>
      </Card>
    </aside>
  );
};

export default RightSidebar;