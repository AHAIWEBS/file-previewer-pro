import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface FeatureItem {
  id: string;
  name: string;
  name_bn: string;
  logo_url: string | null;
  website_url: string | null;
}

interface FeatureSliderProps {
  items: FeatureItem[];
  autoPlayInterval?: number;
}

const FeatureSlider = ({ items, autoPlayInterval = 4000 }: FeatureSliderProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (items.length <= 1) return;
    
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % items.length);
    }, autoPlayInterval);

    return () => clearInterval(timer);
  }, [items.length, autoPlayInterval]);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % items.length);
  };

  if (items.length === 0) return null;

  // Show 5 items at a time on desktop
  const visibleCount = 5;
  const visibleItems = [];
  for (let i = 0; i < Math.min(visibleCount, items.length); i++) {
    const index = (currentIndex + i) % items.length;
    visibleItems.push(items[index]);
  }

  return (
    <div className="relative bg-gradient-to-r from-primary/5 to-accent/5 py-6 px-4 rounded-lg">
      <div className="flex items-center justify-between gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={goToPrevious}
          className="shrink-0 rounded-full"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        <div className="flex-1 overflow-hidden">
          <div className="flex gap-4 justify-center">
            {visibleItems.map((item, idx) => (
              <a
                key={`${item.id}-${idx}`}
                href={item.website_url || "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="block group"
              >
                <Card className="p-3 hover:shadow-lg transition-all duration-300 border group-hover:border-primary min-w-[140px]">
                  <div className="w-full h-12 flex items-center justify-center">
                    <img
                      src={item.logo_url || '/placeholder.svg'}
                      alt={item.name}
                      className="max-w-[120px] h-auto max-h-full object-contain"
                    />
                  </div>
                  <p className="text-xs text-center mt-2 font-medium text-foreground group-hover:text-primary truncate">
                    {item.name_bn}
                  </p>
                </Card>
              </a>
            ))}
          </div>
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={goToNext}
          className="shrink-0 rounded-full"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Dots indicator */}
      <div className="flex justify-center gap-1 mt-4">
        {items.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`w-2 h-2 rounded-full transition-colors ${
              idx === currentIndex ? 'bg-primary' : 'bg-muted-foreground/30'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default FeatureSlider;