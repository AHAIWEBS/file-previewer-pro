import { Badge } from "./ui/badge";
import { cn } from "@/lib/utils";

interface CategoryFilterProps {
  categories: { value: string; label: string }[];
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
}

const CategoryFilter = ({ categories, selectedCategory, onCategoryChange }: CategoryFilterProps) => {
  return (
    <div className="flex flex-wrap gap-2 justify-center py-4">
      <Badge
        variant={selectedCategory === null ? "default" : "outline"}
        className={cn(
          "cursor-pointer transition-all hover:scale-105 px-4 py-2",
          selectedCategory === null && "bg-primary text-primary-foreground"
        )}
        onClick={() => onCategoryChange(null)}
      >
        সব
      </Badge>
      {categories.map((cat) => (
        <Badge
          key={cat.value}
          variant={selectedCategory === cat.value ? "default" : "outline"}
          className={cn(
            "cursor-pointer transition-all hover:scale-105 px-4 py-2",
            selectedCategory === cat.value && "bg-primary text-primary-foreground"
          )}
          onClick={() => onCategoryChange(cat.value)}
        >
          {cat.label}
        </Badge>
      ))}
    </div>
  );
};

export default CategoryFilter;