import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { useToast } from "./ui/use-toast";
import { z } from "zod";

const newspaperSchema = z.object({
  name: z.string().trim().min(1, { message: "নাম অবশ্যই প্রয়োজন" }).max(100, { message: "নাম ১০০ অক্ষরের কম হতে হবে" }),
  website: z.string().trim().url({ message: "সঠিক ওয়েবসাইট URL দিন" }).max(255, { message: "URL ২৫৫ অক্ষরের কম হতে হবে" }),
  description: z.string().trim().max(500, { message: "বিবরণ ৫০০ অক্ষরের কম হতে হবে" }).optional(),
  email: z.string().trim().email({ message: "সঠিক ইমেইল ঠিকানা দিন" }).max(255, { message: "ইমেইল ২৫৫ অক্ষরের কম হতে হবে" }),
});

type NewspaperFormData = z.infer<typeof newspaperSchema>;

export const SubmitNewspaperDialog = () => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<NewspaperFormData>({
    name: "",
    website: "",
    description: "",
    email: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof NewspaperFormData, string>>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setIsSubmitting(true);

    try {
      const validatedData = newspaperSchema.parse(formData);
      
      // Here you would typically send the data to your backend
      console.log("Validated newspaper data:", validatedData);
      
      toast({
        title: "সফলভাবে জমা দেওয়া হয়েছে!",
        description: "আপনার সংবাদপত্রের তথ্য পর্যালোচনা করা হবে।",
      });
      
      setOpen(false);
      setFormData({ name: "", website: "", description: "", email: "" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Partial<Record<keyof NewspaperFormData, string>> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as keyof NewspaperFormData] = err.message;
          }
        });
        setErrors(fieldErrors);
      }
      
      toast({
        title: "ত্রুটি",
        description: "দয়া করে সব ক্ষেত্র সঠিকভাবে পূরণ করুন।",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" className="bg-white text-primary hover:bg-white/90">
          SUBMIT SITE
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">নতুন সংবাদপত্র জমা দিন</DialogTitle>
          <DialogDescription>
            আপনার সংবাদপত্রের তথ্য দিন। আমরা শীঘ্রই পর্যালোচনা করব।
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">সংবাদপত্রের নাম *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="যেমন: প্রথম আলো"
              maxLength={100}
            />
            {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="website">ওয়েবসাইট URL *</Label>
            <Input
              id="website"
              type="url"
              value={formData.website}
              onChange={(e) => setFormData({ ...formData, website: e.target.value })}
              placeholder="https://example.com"
              maxLength={255}
            />
            {errors.website && <p className="text-sm text-destructive">{errors.website}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">যোগাযোগের ইমেইল *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="info@example.com"
              maxLength={255}
            />
            {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">বিবরণ (ঐচ্ছিক)</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="সংবাদপত্র সম্পর্কে কিছু লিখুন..."
              maxLength={500}
              rows={4}
            />
            {errors.description && <p className="text-sm text-destructive">{errors.description}</p>}
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              বাতিল
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1"
            >
              {isSubmitting ? "জমা দেওয়া হচ্ছে..." : "জমা দিন"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
