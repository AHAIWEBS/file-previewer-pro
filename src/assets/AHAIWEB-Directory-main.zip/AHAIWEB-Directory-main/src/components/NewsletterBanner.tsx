import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface BannerItem {
  name: string;
  logo: string;
}

const bannerItems: BannerItem[] = [
  { name: "bdnews24.com", logo: "/placeholder.svg" },
  { name: "JagonNews24", logo: "/placeholder.svg" },
  { name: "Jamuna TV", logo: "/placeholder.svg" },
  { name: "Ekattor TV", logo: "/placeholder.svg" },
  { name: "Independent TV", logo: "/placeholder.svg" },
  { name: "Bangla News", logo: "/placeholder.svg" },
  { name: "DBC News", logo: "/placeholder.svg" },
  { name: "Bangla Tribune", logo: "/placeholder.svg" },
  { name: "Rising BD", logo: "/placeholder.svg" },
  { name: "Dhaka Post", logo: "/placeholder.svg" },
];

const NewsletterBanner = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % bannerItems.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + bannerItems.length) % bannerItems.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % bannerItems.length);
  };

  return (
    <div className="bg-white border-b border-border py-4">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={handlePrev}
            className="w-10 h-10 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex-1 overflow-hidden">
            <div className="flex items-center justify-center gap-8">
              {bannerItems.slice(currentIndex, currentIndex + 5).map((item, index) => (
                <div
                  key={index}
                  className="w-24 h-12 flex items-center justify-center"
                >
                  <img
                    src={item.logo}
                    alt={item.name}
                    className="max-w-full max-h-full object-contain opacity-70 hover:opacity-100 transition-opacity"
                  />
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={handleNext}
            className="w-10 h-10 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewsletterBanner;
