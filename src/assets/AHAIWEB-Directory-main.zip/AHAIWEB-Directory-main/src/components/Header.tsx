import { Menu, LogIn, LogOut, User, LayoutDashboard } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { SubmitNewspaperDialog } from "./SubmitNewspaperDialog";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isAdmin, signOut, loading } = useAuth();
  const navigate = useNavigate();

  const menuItems = [
    { name: "হোম", path: "/" },
    { name: "ডিরেক্টরি", path: "/directory" },
    { name: "ক্যাটাগরি", path: "/categories" },
    { name: "বিভাগীয় পত্রিকা", path: "/division-newspapers" },
  ];

  const handleSignOut = async () => {
    await signOut();
    toast.success('লগআউট সফল');
    navigate('/');
  };

  return (
    <header className="bg-primary text-primary-foreground sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <div className="w-6 h-6 bg-primary rounded-full"></div>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="hover:opacity-80 transition-opacity text-sm font-medium"
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-3">
            <SubmitNewspaperDialog />
            
            {!loading && (
              user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="secondary" size="sm" className="gap-2">
                      <User className="h-4 w-4" />
                      {isAdmin && <span className="text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded">Admin</span>}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="text-muted-foreground text-sm">
                      {user.email}
                    </DropdownMenuItem>
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild className="cursor-pointer">
                          <Link to="/admin" className="flex items-center">
                            <LayoutDashboard className="h-4 w-4 mr-2" />
                            অ্যাডমিন ড্যাশবোর্ড
                          </Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleSignOut} className="text-destructive cursor-pointer">
                      <LogOut className="h-4 w-4 mr-2" />
                      লগআউট
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button variant="secondary" size="sm" asChild>
                  <Link to="/auth" className="gap-2">
                    <LogIn className="h-4 w-4" />
                    লগইন
                  </Link>
                </Button>
              )
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-2">
            {menuItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="hover:opacity-80 transition-opacity text-sm font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="mt-2 flex flex-col gap-2">
              <SubmitNewspaperDialog />
              {!loading && (
                user ? (
                  <Button 
                    variant="secondary" 
                    size="sm" 
                    onClick={() => {
                      handleSignOut();
                      setIsMenuOpen(false);
                    }}
                    className="gap-2"
                  >
                    <LogOut className="h-4 w-4" />
                    লগআউট
                    {isAdmin && <span className="text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded ml-2">Admin</span>}
                  </Button>
                ) : (
                  <Button variant="secondary" size="sm" asChild onClick={() => setIsMenuOpen(false)}>
                    <Link to="/auth" className="gap-2">
                      <LogIn className="h-4 w-4" />
                      লগইন
                    </Link>
                  </Button>
                )
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
