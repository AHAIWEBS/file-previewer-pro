import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Newspaper, TrendingUp, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface NewsSource {
  id: string;
  name_bn: string;
  logo_url: string | null;
  website_url: string | null;
  category: string;
}

const categories = [
  { value: 'national', label: 'জাতীয়', color: 'bg-primary' },
  { value: 'international', label: 'আন্তর্জাতিক', color: 'bg-blue-500' },
  { value: 'sports', label: 'খেলাধুলা', color: 'bg-green-500' },
  { value: 'entertainment', label: 'বিনোদন', color: 'bg-purple-500' },
  { value: 'technology', label: 'প্রযুক্তি', color: 'bg-cyan-500' },
];

const LeftSidebar = () => {
  const [popularSources, setPopularSources] = useState<NewsSource[]>([]);

  useEffect(() => {
    const fetchPopularSources = async () => {
      const { data } = await supabase
        .from('newspapers')
        .select('id, name_bn, logo_url, url, category')
        .eq('is_active', true)
        .limit(8);

      if (data) {
        setPopularSources(data.map(d => ({
          id: d.id,
          name_bn: d.name_bn,
          logo_url: d.logo_url,
          website_url: d.url,
          category: d.category
        })));
      }
    };

    fetchPopularSources();
  }, []);

  return (
    <aside className="space-y-6">
      {/* Categories */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Newspaper className="h-4 w-4 text-primary" />
            ক্যাটাগরি
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {categories.map((cat) => (
            <Badge
              key={cat.value}
              variant="outline"
              className="mr-2 mb-2 cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
            >
              {cat.label}
            </Badge>
          ))}
        </CardContent>
      </Card>

      {/* Popular Sources */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            জনপ্রিয় সোর্স
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {popularSources.slice(0, 6).map((source) => (
            <a
              key={source.id}
              href={source.website_url || "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors group"
            >
              <div className="w-10 h-10 flex items-center justify-center bg-background rounded border">
                <img
                  src={source.logo_url || '/placeholder.svg'}
                  alt={source.name_bn}
                  className="max-w-[32px] h-auto max-h-8 object-contain"
                />
              </div>
              <span className="text-sm font-medium group-hover:text-primary truncate flex-1">
                {source.name_bn}
              </span>
            </a>
          ))}
        </CardContent>
      </Card>

      {/* Latest Updates */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            সর্বশেষ আপডেট
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">
            আজকের তারিখ: {new Date().toLocaleDateString('bn-BD')}
          </p>
        </CardContent>
      </Card>
    </aside>
  );
};

export default LeftSidebar;