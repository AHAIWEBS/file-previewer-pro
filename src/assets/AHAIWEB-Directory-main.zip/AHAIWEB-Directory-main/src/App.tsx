import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import AdminDashboard from "./pages/AdminDashboard";
import Categories from "./pages/Categories";
import DivisionNewspapers from "./pages/DivisionNewspapers";
import Directory from "./pages/Directory";
import NotFound from "./pages/NotFound";
import Government from "./pages/directory/Government";
import Phone from "./pages/directory/Phone";
import Travel from "./pages/directory/Travel";
import DailyLife from "./pages/directory/DailyLife";
import Social from "./pages/directory/Social";
import AI from "./pages/directory/AI";
import Software from "./pages/directory/Software";
import Apps from "./pages/directory/Apps";
import TV from "./pages/directory/TV";
import People from "./pages/directory/People";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/division-newspapers" element={<DivisionNewspapers />} />
            <Route path="/directory" element={<Directory />} />
            <Route path="/directory/government" element={<Government />} />
            <Route path="/directory/phone" element={<Phone />} />
            <Route path="/directory/travel" element={<Travel />} />
            <Route path="/directory/daily-life" element={<DailyLife />} />
            <Route path="/directory/social" element={<Social />} />
            <Route path="/directory/ai" element={<AI />} />
            <Route path="/directory/software" element={<Software />} />
            <Route path="/directory/apps" element={<Apps />} />
            <Route path="/directory/tv" element={<TV />} />
            <Route path="/directory/people" element={<People />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
