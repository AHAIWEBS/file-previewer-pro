import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DirectoryItem {
  id: string;
  subcategory: string | null;
  name_bn: string;
  name_en: string | null;
  url: string | null;
  phone: string | null;
  description: string | null;
}

interface GroupedItems {
  subcategory: string;
  items: DirectoryItem[];
}

export const useDirectoryData = (categorySlug: string) => {
  const [items, setItems] = useState<DirectoryItem[]>([]);
  const [groupedItems, setGroupedItems] = useState<GroupedItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);

      // First get the category ID
      const { data: category, error: catError } = await supabase
        .from('directory_categories')
        .select('id')
        .eq('slug', categorySlug)
        .maybeSingle();

      if (catError) {
        setError('ক্যাটাগরি লোড করতে সমস্যা হয়েছে');
        setLoading(false);
        return;
      }

      if (!category) {
        setError('ক্যাটাগরি পাওয়া যায়নি');
        setLoading(false);
        return;
      }

      // Then get the items
      const { data: itemsData, error: itemsError } = await supabase
        .from('directory_items')
        .select('*')
        .eq('category_id', category.id)
        .eq('is_active', true)
        .order('subcategory')
        .order('sort_order');

      if (itemsError) {
        setError('আইটেম লোড করতে সমস্যা হয়েছে');
        setLoading(false);
        return;
      }

      setItems(itemsData || []);

      // Group items by subcategory
      const grouped: Record<string, DirectoryItem[]> = {};
      (itemsData || []).forEach((item) => {
        const sub = item.subcategory || 'অন্যান্য';
        if (!grouped[sub]) grouped[sub] = [];
        grouped[sub].push(item);
      });

      setGroupedItems(
        Object.entries(grouped).map(([subcategory, items]) => ({
          subcategory,
          items,
        }))
      );

      setLoading(false);
    };

    fetchData();
  }, [categorySlug]);

  return { items, groupedItems, loading, error };
};
