-- Create directory_categories table
CREATE TABLE public.directory_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name_bn TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  color TEXT DEFAULT 'bg-blue-500',
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create directory_items table
CREATE TABLE public.directory_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID NOT NULL REFERENCES public.directory_categories(id) ON DELETE CASCADE,
  subcategory TEXT,
  name_bn TEXT NOT NULL,
  name_en TEXT,
  url TEXT,
  phone TEXT,
  description TEXT,
  icon TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create site_settings table
CREATE TABLE public.site_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  value JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.directory_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.directory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- RLS policies for directory_categories (public read, admin write)
CREATE POLICY "Anyone can view active directory categories" 
ON public.directory_categories FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage directory categories" 
ON public.directory_categories FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS policies for directory_items (public read, admin write)
CREATE POLICY "Anyone can view active directory items" 
ON public.directory_items FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage directory items" 
ON public.directory_items FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- RLS policies for site_settings (public read, admin write)
CREATE POLICY "Anyone can view site settings" 
ON public.site_settings FOR SELECT 
USING (true);

CREATE POLICY "Admins can manage site settings" 
ON public.site_settings FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create indexes
CREATE INDEX idx_directory_items_category ON public.directory_items(category_id);
CREATE INDEX idx_directory_items_subcategory ON public.directory_items(subcategory);
CREATE INDEX idx_site_settings_key ON public.site_settings(key);

-- Triggers for updated_at
CREATE TRIGGER update_directory_categories_updated_at
BEFORE UPDATE ON public.directory_categories
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_directory_items_updated_at
BEFORE UPDATE ON public.directory_items
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_site_settings_updated_at
BEFORE UPDATE ON public.site_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();