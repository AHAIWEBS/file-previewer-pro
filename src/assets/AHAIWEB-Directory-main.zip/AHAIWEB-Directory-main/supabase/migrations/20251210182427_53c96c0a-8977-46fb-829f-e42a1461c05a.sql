-- Create newspapers table
CREATE TABLE public.newspapers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  name_bn TEXT NOT NULL,
  url TEXT NOT NULL,
  logo_url TEXT,
  category TEXT NOT NULL DEFAULT 'national',
  division TEXT,
  district TEXT,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.newspapers ENABLE ROW LEVEL SECURITY;

-- Everyone can view active newspapers
CREATE POLICY "Anyone can view active newspapers"
ON public.newspapers
FOR SELECT
USING (is_active = true);

-- Admins can view all newspapers
CREATE POLICY "Admins can view all newspapers"
ON public.newspapers
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can insert newspapers
CREATE POLICY "Admins can insert newspapers"
ON public.newspapers
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admins can update newspapers
CREATE POLICY "Admins can update newspapers"
ON public.newspapers
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can delete newspapers
CREATE POLICY "Admins can delete newspapers"
ON public.newspapers
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Add trigger for updated_at
CREATE TRIGGER update_newspapers_updated_at
BEFORE UPDATE ON public.newspapers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Update profiles RLS to allow admins to view all profiles
CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));