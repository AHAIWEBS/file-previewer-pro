import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RSSItem {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  source: string;
  source_bn: string;
  source_logo: string | null;
}

// Simple RSS/XML parser
function parseRSSFeed(xml: string, sourceName: string, sourceBn: string, sourceLogo: string | null): RSSItem[] {
  const items: RSSItem[] = [];
  
  try {
    // Extract items from RSS feed
    const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
    let match;
    
    while ((match = itemRegex.exec(xml)) !== null) {
      const itemXml = match[1];
      
      const title = extractTag(itemXml, 'title');
      const link = extractTag(itemXml, 'link');
      const description = extractTag(itemXml, 'description');
      const pubDate = extractTag(itemXml, 'pubDate');
      
      if (title && link) {
        items.push({
          title: cleanHtml(title),
          link,
          description: cleanHtml(description || ''),
          pubDate: pubDate || new Date().toISOString(),
          source: sourceName,
          source_bn: sourceBn,
          source_logo: sourceLogo
        });
      }
    }
  } catch (error) {
    console.error('Error parsing RSS:', error);
  }
  
  return items;
}

function extractTag(xml: string, tag: string): string | null {
  const cdataRegex = new RegExp(`<${tag}><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${tag}>`, 'i');
  const cdataMatch = xml.match(cdataRegex);
  if (cdataMatch) return cdataMatch[1];
  
  const simpleRegex = new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const simpleMatch = xml.match(simpleRegex);
  return simpleMatch ? simpleMatch[1] : null;
}

function cleanHtml(text: string): string {
  return text
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('Fetching news sources with RSS feeds...');

    // Fetch all active news sources with RSS feeds
    const { data: sources, error: sourcesError } = await supabase
      .from('news_sources')
      .select('*')
      .eq('is_active', true)
      .not('rss_feed_url', 'is', null);

    if (sourcesError) {
      console.error('Error fetching sources:', sourcesError);
      throw sourcesError;
    }

    console.log(`Found ${sources?.length || 0} sources with RSS feeds`);

    const allItems: RSSItem[] = [];
    const errors: string[] = [];

    // Fetch RSS from each source
    for (const source of sources || []) {
      if (!source.rss_feed_url) continue;

      try {
        console.log(`Fetching RSS from: ${source.name} - ${source.rss_feed_url}`);
        
        const response = await fetch(source.rss_feed_url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; RSSBot/1.0)',
            'Accept': 'application/rss+xml, application/xml, text/xml, */*'
          }
        });

        if (!response.ok) {
          errors.push(`${source.name}: HTTP ${response.status}`);
          continue;
        }

        const xml = await response.text();
        const items = parseRSSFeed(xml, source.name, source.name_bn, source.logo_url);
        
        console.log(`Parsed ${items.length} items from ${source.name}`);
        allItems.push(...items.slice(0, 10)); // Limit to 10 items per source
        
      } catch (error: any) {
        console.error(`Error fetching RSS from ${source.name}:`, error.message);
        errors.push(`${source.name}: ${error.message}`);
      }
    }

    // Sort by date (newest first)
    allItems.sort((a, b) => {
      const dateA = new Date(a.pubDate).getTime();
      const dateB = new Date(b.pubDate).getTime();
      return dateB - dateA;
    });

    console.log(`Total items fetched: ${allItems.length}`);
    console.log(`Errors: ${errors.length}`);

    return new Response(
      JSON.stringify({
        success: true,
        items: allItems.slice(0, 50), // Return max 50 items
        total: allItems.length,
        errors: errors.length > 0 ? errors : undefined,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Error in fetch-rss-feeds:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});